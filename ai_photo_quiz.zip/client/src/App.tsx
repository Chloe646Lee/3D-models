import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Leaderboard from "./pages/Leaderboard";
import DailyChallenge from "./pages/DailyChallenge";
import DailyChallengeLeaderboard from "./pages/DailyChallengeLeaderboard";
import { DailyChallengeNotification, useNotifications } from "./components/DailyChallengeNotification";
import { useEffect } from "react";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"//"} component={Home} />
      <Route path={"/leaderboard"} component={Leaderboard} />
      <Route path={"/daily-challenge"} component={DailyChallenge} />
      <Route path={"/daily-leaderboard"} component={DailyChallengeLeaderboard} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  const { notifications, addNotification, dismissNotification } = useNotifications();

  // Simulate receiving a notification when app loads
  // In production, this would come from a WebSocket or polling mechanism
  useEffect(() => {
    // Check if there's a new challenge notification to show
    const checkForNewChallenge = () => {
      const lastNotificationTime = localStorage.getItem('lastChallengeNotificationTime');
      const now = Date.now();
      
      // Show notification if it's been more than 24 hours since last notification
      if (!lastNotificationTime || now - parseInt(lastNotificationTime) > 24 * 60 * 60 * 1000) {
        addNotification(
          '🎮 新的每日挑战发布！',
          '快来参加今天的挑战，与其他玩家竞争排名吧！',
          'challenge'
        );
        localStorage.setItem('lastChallengeNotificationTime', now.toString());
      }
    };

    checkForNewChallenge();
  }, [addNotification]);

  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <DailyChallengeNotification
            notifications={notifications}
            onDismiss={dismissNotification}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
