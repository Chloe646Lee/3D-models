/**
 * Home Page - AI vs Real Photo Quiz Game
 * 
 * Design Philosophy: Warm Humanist + Playful
 * - Friendly, encouraging interface
 * - Smooth animations and transitions
 * - Achievement badges and celebration effects
 * - Responsive card-based layout
 */

import { useEffect, useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { gamePhotos, getEarnedBadges, calculateAccuracy, getEncouragingMessage, shuffleArray, type GameState, type Answer } from '@/lib/gameData';
import { motion, AnimatePresence } from 'framer-motion';
import { getLoginUrl } from '@/const';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import ResultDetails from '@/components/ResultDetails';

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const saveScoreMutation = trpc.leaderboard.saveScore.useMutation();
  const [isSavingScore, setIsSavingScore] = useState(false);
  
  const [gameState, setGameState] = useState<GameState>({
    currentPhotoIndex: 0,
    score: 0,
    totalPhotos: gamePhotos.length,
    answers: [],
    isGameOver: false,
    selectedAnswer: null,
    showResult: false,
  });

  const [shuffledPhotos, setShuffledPhotos] = useState(gamePhotos);
  const [showResultDetails, setShowResultDetails] = useState(false);

  // Shuffle photos on mount
  useEffect(() => {
    const shuffled = shuffleArray(gamePhotos);
    setShuffledPhotos(shuffled);
  }, []);

  const currentPhoto = shuffledPhotos[gameState.currentPhotoIndex];
  const earnedBadges = getEarnedBadges(gameState.score, gameState.totalPhotos);
  const accuracy = calculateAccuracy(gameState.score, gameState.totalPhotos);

  const handleAnswer = (answer: 'ai' | 'real') => {
    if (gameState.showResult) return;

    const isCorrect = answer === (currentPhoto.isAI ? 'ai' : 'real');
    const newAnswer: Answer = {
      photoId: currentPhoto.id,
      userAnswer: answer,
      isCorrect,
      timestamp: Date.now(),
    };

    setGameState((prev) => ({
      ...prev,
      selectedAnswer: answer,
      showResult: true,
      score: isCorrect ? prev.score + 1 : prev.score,
      answers: [...prev.answers, newAnswer],
    }));
  };

  const handleNext = () => {
    if (gameState.currentPhotoIndex < gameState.totalPhotos - 1) {
      setGameState((prev) => ({
        ...prev,
        currentPhotoIndex: prev.currentPhotoIndex + 1,
        selectedAnswer: null,
        showResult: false,
      }));
    } else {
      setGameState((prev) => ({
        ...prev,
        isGameOver: true,
      }));
    }
  };

  const handleRestart = () => {
    const shuffled = shuffleArray(gamePhotos);
    setShuffledPhotos(shuffled);
    setGameState({
      currentPhotoIndex: 0,
      score: 0,
      totalPhotos: gamePhotos.length,
      answers: [],
      isGameOver: false,
      selectedAnswer: null,
      showResult: false,
    });
  };

  const handleSaveScore = async () => {
    if (!isAuthenticated) return;
    
    setIsSavingScore(true);
    try {
      const accuracy = calculateAccuracy(gameState.score, gameState.totalPhotos);
      await saveScoreMutation.mutateAsync({
        score: gameState.score,
        totalPhotos: gameState.totalPhotos,
        accuracy,
        answers: JSON.stringify(gameState.answers),
      });
    } catch (error) {
      console.error('Failed to save score:', error);
    } finally {
      setIsSavingScore(false);
    }
  };

  const handleViewLeaderboard = async () => {
    if (isAuthenticated) {
      await handleSaveScore();
    }
    setLocation('/leaderboard');
  };

  if (gameState.isGameOver) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, type: 'spring' }}
          className="w-full max-w-md"
        >
          <Card className="p-8 shadow-2xl border-0 bg-white">
            {showResultDetails ? (
              <ResultDetails
                photos={shuffledPhotos}
                answers={gameState.answers}
                onClose={() => setShowResultDetails(false)}
              />
            ) : (
            <div className="text-center">
              {/* Final Score */}
              <motion.div
                initial={{ y: -20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="mb-6"
              >
                <h1 className="text-5xl font-bold text-[#ff9a56] mb-2">
                  {gameState.score} / {gameState.totalPhotos}
                </h1>
                <p className="text-2xl text-[#2c2c2c] font-semibold mb-2">
                  {accuracy}% 准确率
                </p>
              </motion.div>

              {/* Encouraging Message */}
              <motion.p
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="mb-8"
              >
                {getEncouragingMessage(calculateAccuracy(gameState.score, shuffledPhotos.length))}
              </motion.p>

              {/* Badges */}
              {earnedBadges.length > 0 && (
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="mb-8"
                >
                  <p className="text-sm text-[#6b6b6b] mb-3 font-semibold">
                    🎖️ 获得的成就
                  </p>
                  <div className="flex flex-wrap justify-center gap-3">
                    {earnedBadges.map((badge) => (
                      <motion.div
                        key={badge.id}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', delay: 0.8 }}
                        className="flex flex-col items-center"
                      >
                        <div className="text-4xl mb-1">{badge.icon}</div>
                        <p className="text-xs text-[#6b6b6b] text-center">
                          {badge.name}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Leaderboard Button */}
              {isAuthenticated && (
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.8 }}
                  className="mb-6"
                >
                  <Button
                    onClick={handleViewLeaderboard}
                    disabled={isSavingScore}
                    className="w-full bg-[#7ba3d4] hover:bg-[#6b92c3] text-white font-semibold py-3 rounded-2xl transition-all duration-300 transform hover:scale-105 disabled:opacity-50"
                  >
                    {isSavingScore ? '💾 保存中...' : '📊 查看排行榜'}
                  </Button>
                </motion.div>
              )}

              {/* Result Details Button */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.9 }}
                className="mb-3"
              >
                <Button
                  onClick={() => setShowResultDetails(!showResultDetails)}
                  className="w-full bg-[#7ba3d4] hover:bg-[#6b92c3] text-white font-semibold py-3 rounded-2xl transition-all duration-300 transform hover:scale-105"
                >
                  {showResultDetails ? '隐藏' : '显示'} 📋 详细答题回顾
                </Button>
              </motion.div>

              {/* Restart Button */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1 }}
                className="flex gap-3"
              >
                <Button
                  onClick={handleRestart}
                  className="flex-1 bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-6 rounded-2xl text-lg transition-all duration-300 transform hover:scale-105"
                >
                  再来一局
                </Button>
              </motion.div>
            </div>
            )}
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        {/* Navigation */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="flex justify-between items-center mb-8"
        >
          <h1 className="text-2xl font-bold text-[#2c2c2c]">
            🎮 AI vs 真实摄影
          </h1>
          {isAuthenticated && (
            <div className="flex gap-2">
              <Button
                onClick={() => setLocation('/leaderboard')}
                className="bg-white text-[#2c2c2c] border border-[#e8e4db] hover:bg-[#f5f1e8] font-semibold py-2 px-4 rounded-xl text-sm"
              >
                📊 排行榜
              </Button>
              <Button
                onClick={() => setLocation('/daily-challenge')}
                className="bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-2 px-4 rounded-xl text-sm"
              >
                📅 每日挑战
              </Button>
            </div>
          )}
        </motion.div>

        {/* Header */}
        <motion.div
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#2c2c2c] mb-2">
            今日挑战
          </h2>
          <p className="text-[#6b6b6b] text-lg">
            你能分辨出哪些是 AI 生成的吗？
          </p>
          {isAuthenticated && (
            <p className="text-sm text-[#ff9a56] mt-2 font-semibold">
              👋 欢迎，{user?.name}！
            </p>
          )}
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="mb-8 origin-left"
        >
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-semibold text-[#2c2c2c]">
              进度
            </span>
            <span className="text-sm font-semibold text-[#ff9a56]">
              {gameState.currentPhotoIndex + 1} / {shuffledPhotos.length}
            </span>
          </div>
          <div className="w-full h-3 bg-[#e8e4db] rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{
                width: `${((gameState.currentPhotoIndex + 1) / shuffledPhotos.length) * 100}%`,
              }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-[#ff9a56] to-[#ff8c42]"
            />
          </div>
        </motion.div>

        {/* Photo Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={gameState.currentPhotoIndex}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.4 }}
            className="mb-8"
          >
            <Card className="overflow-hidden shadow-xl border-0 bg-white">
              <div className="relative">
                {/* Image Container */}
                <div className="relative w-full h-80 md:h-96 bg-[#f5f1e8] overflow-hidden">
                  <motion.img
                    src={currentPhoto.imageUrl}
                    alt={currentPhoto.description}
                    className="w-full h-full object-cover"
                    initial={{ filter: 'blur(10px)', opacity: 0 }}
                    animate={{ filter: 'blur(0px)', opacity: 1 }}
                    transition={{ duration: 0.6 }}
                  />

                  {/* Category Badge */}
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="absolute top-4 left-4 bg-white/90 backdrop-blur px-4 py-2 rounded-full text-sm font-semibold text-[#2c2c2c]"
                  >
                    {currentPhoto.category === 'landscape' && '🏔️ 风景'}
                    {currentPhoto.category === 'portrait' && '👤 人物'}
                    {currentPhoto.category === 'nature' && '🌊 自然'}
                    {currentPhoto.category === 'urban' && '🏙️ 城市'}
                    {currentPhoto.category === 'food' && '🍽️ 美食'}
                  </motion.div>
                </div>

                {/* Description */}
                <div className="p-6 bg-white">
                  <p className="text-[#6b6b6b] text-center text-sm md:text-base">
                    {currentPhoto.description}
                  </p>
                </div>
              </div>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Question */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mb-8"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-[#2c2c2c]">
            这是 AI 生成的还是真实摄影？
          </h2>
        </motion.div>

        {/* Answer Buttons */}
        <AnimatePresence>
          {!gameState.showResult ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: 0.4 }}
              className="flex gap-4 mb-8"
            >
              <Button
                onClick={() => handleAnswer('ai')}
                className="flex-1 bg-[#7ba3d4] hover:bg-[#6b92c3] text-white font-bold py-6 rounded-2xl text-lg transition-all duration-300 transform hover:scale-105 active:scale-95"
              >
                🤖 AI 生成
              </Button>
              <Button
                onClick={() => handleAnswer('real')}
                className="flex-1 bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-bold py-6 rounded-2xl text-lg transition-all duration-300 transform hover:scale-105 active:scale-95"
              >
                📸 真实摄影
              </Button>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.4 }}
              className="mb-8"
            >
              {/* Result Card */}
              <Card className={`p-6 border-0 shadow-lg ${
                gameState.answers[gameState.answers.length - 1]?.isCorrect
                  ? 'bg-gradient-to-br from-[#e8f5e9] to-[#c8e6c9]'
                  : 'bg-gradient-to-br from-[#ffebee] to-[#ffcdd2]'
              }`}>
                <div className="text-center">
                  {gameState.answers[gameState.answers.length - 1]?.isCorrect ? (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', delay: 0.1 }}
                    >
                      <div className="text-6xl mb-3">✨</div>
                      <h3 className="text-2xl font-bold text-[#2c2c2c] mb-2">
                        答对了！
                      </h3>
                      <p className="text-[#6b6b6b]">
                        这{currentPhoto.isAI ? '确实是 AI 生成的' : '确实是真实摄影作品'}！
                      </p>
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', delay: 0.1 }}
                    >
                      <div className="text-6xl mb-3">💭</div>
                      <h3 className="text-2xl font-bold text-[#2c2c2c] mb-2">
                        答错了
                      </h3>
                      <p className="text-[#6b6b6b]">
                        这{currentPhoto.isAI ? '是 AI 生成的' : '是真实摄影作品'}。AI 真的很逼真呢！
                      </p>
                    </motion.div>
                  )}
                </div>
              </Card>

              {/* Score Display */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-center mt-6 mb-6"
              >
                <p className="text-lg font-semibold text-[#2c2c2c]">
                  当前得分: <span className="text-[#ff9a56]">{gameState.score}</span> / {shuffledPhotos.length}
                </p>
              </motion.div>

              {/* Next Button */}
              <Button
                onClick={handleNext}
                className="w-full bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-bold py-6 rounded-2xl text-lg transition-all duration-300 transform hover:scale-105"
              >
                {gameState.currentPhotoIndex < shuffledPhotos.length - 1
                  ? '下一张'
                  : '查看结果'}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Login Prompt */}
        {!isAuthenticated && gameState.isGameOver && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-center mt-8 p-4 bg-white/50 rounded-2xl border border-[#e8e4db]"
          >
            <p className="text-[#6b6b6b] mb-3">
              🔐 登录后可以保存得分并查看排行榜
            </p>
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-2 px-6 rounded-xl"
            >
              登录
            </Button>
          </motion.div>
        )}

        {/* Score Summary */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-sm text-[#6b6b6b] mt-8"
        >
          <p>
            💡 提示：仔细观察细节、纹理和光影，可能会帮助你识别！
          </p>
        </motion.div>
      </div>
    </div>
  );
}
