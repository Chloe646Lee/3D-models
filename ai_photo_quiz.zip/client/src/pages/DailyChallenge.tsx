/**
 * Daily Challenge Page - Play today's themed challenge
 */

import { useEffect, useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { trpc } from '@/lib/trpc';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { gamePhotos, calculateAccuracy, getEncouragingMessage, type Answer } from '@/lib/gameData';

interface DailyChallengePhoto {
  id: string;
  imageUrl: string;
  isAI: boolean;
  category: string;
  description: string;
}

interface GameState {
  currentPhotoIndex: number;
  score: number;
  totalPhotos: number;
  answers: Answer[];
  isGameOver: boolean;
  selectedAnswer: 'ai' | 'real' | null;
  showResult: boolean;
}

export default function DailyChallenge() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  
  // Fetch today's daily challenge
  const { data: todaysChallenge, isLoading: challengeLoading } = trpc.dailyChallenge.getTodaysChallenge.useQuery();
  
  // Save score mutation
  const saveScoreMutation = trpc.dailyChallenge.saveScore.useMutation();
  const [isSavingScore, setIsSavingScore] = useState(false);

  const [gameState, setGameState] = useState<GameState>({
    currentPhotoIndex: 0,
    score: 0,
    totalPhotos: 0,
    answers: [],
    isGameOver: false,
    selectedAnswer: null,
    showResult: false,
  });

  const [challengePhotos, setChallengePhotos] = useState<DailyChallengePhoto[]>([]);

  // Initialize challenge photos when challenge data is loaded
  useEffect(() => {
    if (todaysChallenge && todaysChallenge.photoIds) {
      const photoIds = todaysChallenge.photoIds;
      const photos = gamePhotos.filter(p => photoIds.includes(p.id));
      setChallengePhotos(photos);
      setGameState(prev => ({
        ...prev,
        totalPhotos: photos.length,
      }));
    }
  }, [todaysChallenge]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, type: 'spring' }}
          className="w-full max-w-md text-center"
        >
          <Card className="p-8 shadow-2xl border-0 bg-white">
            <div className="text-6xl mb-4">🔐</div>
            <h1 className="text-3xl font-bold text-[#2c2c2c] mb-4">
              需要登录
            </h1>
            <p className="text-[#6b6b6b] mb-6">
              请登录后参加每日挑战
            </p>
            <Button
              onClick={() => setLocation('/')}
              className="w-full bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-3 rounded-2xl"
            >
              返回首页
            </Button>
          </Card>
        </motion.div>
      </div>
    );
  }

  if (challengeLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          className="text-6xl"
        >
          ⏳
        </motion.div>
      </div>
    );
  }

  if (!todaysChallenge) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, type: 'spring' }}
          className="w-full max-w-md text-center"
        >
          <Card className="p-8 shadow-2xl border-0 bg-white">
            <div className="text-6xl mb-4">📅</div>
            <h1 className="text-3xl font-bold text-[#2c2c2c] mb-4">
              今日挑战未就绪
            </h1>
            <p className="text-[#6b6b6b] mb-6">
              请稍后再来，我们正在准备今天的挑战
            </p>
            <Button
              onClick={() => setLocation('/')}
              className="w-full bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-3 rounded-2xl"
            >
              返回首页
            </Button>
          </Card>
        </motion.div>
      </div>
    );
  }

  const currentPhoto = challengePhotos[gameState.currentPhotoIndex];
  const accuracy = calculateAccuracy(gameState.score, gameState.totalPhotos);

  const handleAnswer = (answer: 'ai' | 'real') => {
    if (gameState.showResult || !currentPhoto) return;

    const isCorrect = answer === (currentPhoto.isAI ? 'ai' : 'real');
    const newAnswer: Answer = {
      photoId: currentPhoto.id,
      userAnswer: answer,
      isCorrect,
      timestamp: Date.now(),
    };

    setGameState((prev) => ({
      ...prev,
      selectedAnswer: answer,
      showResult: true,
      score: isCorrect ? prev.score + 1 : prev.score,
      answers: [...prev.answers, newAnswer],
    }));
  };

  const handleNext = () => {
    if (gameState.currentPhotoIndex < gameState.totalPhotos - 1) {
      setGameState((prev) => ({
        ...prev,
        currentPhotoIndex: prev.currentPhotoIndex + 1,
        selectedAnswer: null,
        showResult: false,
      }));
    } else {
      setGameState((prev) => ({
        ...prev,
        isGameOver: true,
      }));
    }
  };

  const handleSaveScore = async () => {
    if (!todaysChallenge) return;
    
    setIsSavingScore(true);
    try {
      await saveScoreMutation.mutateAsync({
        dailyChallengeId: todaysChallenge.id,
        score: gameState.score,
        totalPhotos: gameState.totalPhotos,
        accuracy,
        answers: JSON.stringify(gameState.answers),
      });
    } catch (error) {
      console.error('Failed to save score:', error);
    } finally {
      setIsSavingScore(false);
    }
  };

  const handleViewLeaderboard = async () => {
    await handleSaveScore();
    setLocation('/daily-leaderboard');
  };

  const handleRestart = () => {
    setGameState({
      currentPhotoIndex: 0,
      score: 0,
      totalPhotos: gameState.totalPhotos,
      answers: [],
      isGameOver: false,
      selectedAnswer: null,
      showResult: false,
    });
  };

  // Game Over Screen
  if (gameState.isGameOver) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, type: 'spring' }}
          className="w-full max-w-md"
        >
          <Card className="p-8 shadow-2xl border-0 bg-white">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', delay: 0.2 }}
              className="text-6xl text-center mb-6"
            >
              🎉
            </motion.div>

            <h1 className="text-4xl font-bold text-center text-[#2c2c2c] mb-4">
              挑战完成！
            </h1>

            <div className="bg-gradient-to-r from-[#ff9a56] to-[#ff8c42] rounded-2xl p-6 mb-6 text-white">
              <p className="text-sm opacity-90 mb-2">最终得分</p>
              <p className="text-5xl font-bold">{accuracy}%</p>
              <p className="text-lg mt-2">
                {gameState.score} / {gameState.totalPhotos} 正确
              </p>
            </div>

            <p className="text-center text-[#6b6b6b] mb-6 text-lg">
              {getEncouragingMessage(calculateAccuracy(gameState.score, gameState.totalPhotos))}
            </p>

            <div className="space-y-3">
              <Button
                onClick={handleViewLeaderboard}
                disabled={isSavingScore}
                className="w-full bg-[#7ba3d4] hover:bg-[#6b92c3] text-white font-semibold py-3 rounded-2xl"
              >
                {isSavingScore ? '💾 保存中...' : '📊 查看排行榜'}
              </Button>

              <Button
                onClick={handleRestart}
                className="w-full bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-3 rounded-2xl"
              >
                🔄 再来一次
              </Button>

              <Button
                onClick={() => setLocation('/')}
                className="w-full bg-white text-[#2c2c2c] border border-[#e8e4db] hover:bg-[#f5f1e8] font-semibold py-3 rounded-2xl"
              >
                ← 返回首页
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  // Game Screen
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#2c2c2c]">
                📅 {todaysChallenge.theme}
              </h1>
              <p className="text-[#6b6b6b] mt-2">{todaysChallenge.description}</p>
            </div>
            <Button
              onClick={() => setLocation('/')}
              className="bg-white text-[#2c2c2c] border border-[#e8e4db] hover:bg-[#f5f1e8] font-semibold py-2 px-4 rounded-xl"
            >
              ✕
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-[#e8e4db] rounded-full h-3 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${((gameState.currentPhotoIndex + 1) / gameState.totalPhotos) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="bg-gradient-to-r from-[#ff9a56] to-[#ff8c42] h-full"
            />
          </div>
          <p className="text-right text-sm text-[#6b6b6b] mt-2">
            {gameState.currentPhotoIndex + 1} / {gameState.totalPhotos}
          </p>
        </motion.div>

        {/* Photo Card */}
        {currentPhoto && (
          <motion.div
            key={gameState.currentPhotoIndex}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="mb-8"
          >
            <Card className="overflow-hidden shadow-2xl border-0 bg-white">
              <div className="relative">
                <img
                  src={currentPhoto.imageUrl}
                  alt={currentPhoto.description}
                  className="w-full h-96 object-cover"
                />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-4 py-2 rounded-full">
                  <span className="font-semibold text-[#2c2c2c]">
                    {currentPhoto.category === 'landscape' && '🏔️ 风景'}
                    {currentPhoto.category === 'portrait' && '👤 人物'}
                    {currentPhoto.category === 'nature' && '🌿 自然'}
                    {currentPhoto.category === 'urban' && '🏙️ 城市'}
                    {currentPhoto.category === 'food' && '🍽️ 美食'}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <p className="text-[#6b6b6b] text-center mb-6">
                  {currentPhoto.description}
                </p>

                <AnimatePresence>
                  {gameState.showResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className={`p-4 rounded-2xl mb-6 text-center font-semibold ${
                        gameState.answers[gameState.answers.length - 1]?.isCorrect
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }`}
                    >
                      {gameState.answers[gameState.answers.length - 1]?.isCorrect
                        ? '✅ 正确！'
                        : '❌ 错误'}
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex gap-4">
                  <Button
                    onClick={() => handleAnswer('ai')}
                    disabled={gameState.showResult}
                    className={`flex-1 py-3 rounded-2xl font-semibold transition-all ${
                      gameState.selectedAnswer === 'ai'
                        ? 'bg-[#ff9a56] text-white'
                        : 'bg-white text-[#2c2c2c] border border-[#e8e4db] hover:bg-[#f5f1e8]'
                    }`}
                  >
                    🤖 AI 生成
                  </Button>

                  <Button
                    onClick={() => handleAnswer('real')}
                    disabled={gameState.showResult}
                    className={`flex-1 py-3 rounded-2xl font-semibold transition-all ${
                      gameState.selectedAnswer === 'real'
                        ? 'bg-[#7ba3d4] text-white'
                        : 'bg-white text-[#2c2c2c] border border-[#e8e4db] hover:bg-[#f5f1e8]'
                    }`}
                  >
                    📸 真实摄影
                  </Button>
                </div>

                {gameState.showResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4"
                  >
                    <Button
                      onClick={handleNext}
                      className="w-full bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-3 rounded-2xl"
                    >
                      下一张 →
                    </Button>
                  </motion.div>
                )}
              </div>
            </Card>
          </motion.div>
        )}

        {/* Score Display */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center"
        >
          <p className="text-[#6b6b6b] text-lg">
            当前得分: <span className="font-bold text-[#ff9a56]">{gameState.score}</span> / {gameState.totalPhotos}
          </p>
        </motion.div>
      </div>
    </div>
  );
}
