import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function NotFound() {
  const [, setLocation] = useLocation();

  const handleGoHome = () => {
    setLocation("/");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3]">
      <Card className="w-full max-w-lg mx-4 shadow-xl border-0 bg-white">
        <CardContent className="pt-8 pb-8 text-center">
          <div className="text-6xl mb-6">😕</div>

          <h1 className="text-4xl font-bold text-[#2c2c2c] mb-2">404</h1>

          <h2 className="text-xl font-semibold text-[#6b6b6b] mb-4">
            页面未找到
          </h2>

          <p className="text-[#6b6b6b] mb-8 leading-relaxed">
            抱歉，您访问的页面不存在。
            <br />
            它可能已被移动或删除。
          </p>

          <div
            id="not-found-button-group"
            className="flex flex-col sm:flex-row gap-3 justify-center"
          >
            <Button
              onClick={handleGoHome}
              className="bg-[#ff9a56] hover:bg-[#ff8c42] text-white px-6 py-2.5 rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg font-semibold"
            >
              返回首页
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
