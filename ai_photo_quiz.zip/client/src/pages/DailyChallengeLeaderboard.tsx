/**
 * Daily Challenge Leaderboard - Show today's challenge rankings
 */

import { useEffect, useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { trpc } from '@/lib/trpc';
import { motion } from 'framer-motion';
import { useLocation } from 'wouter';

export default function DailyChallengeLeaderboard() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch today's daily challenge
  const { data: todaysChallenge } = trpc.dailyChallenge.getTodaysChallenge.useQuery();

  // Fetch top scores for today's challenge
  const { data: topScores, isLoading: topScoresLoading } = trpc.dailyChallenge.getTopScores.useQuery(
    { dailyChallengeId: todaysChallenge?.id || 0, limit: 50 },
    { enabled: !!todaysChallenge }
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, type: 'spring' }}
          className="w-full max-w-md text-center"
        >
          <Card className="p-8 shadow-2xl border-0 bg-white">
            <div className="text-6xl mb-4">🔐</div>
            <h1 className="text-3xl font-bold text-[#2c2c2c] mb-4">
              需要登录
            </h1>
            <p className="text-[#6b6b6b] mb-6">
              请登录后查看排行榜
            </p>
            <Button
              onClick={() => setLocation('/')}
              className="w-full bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-3 rounded-2xl"
            >
              返回首页
            </Button>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f3] via-[#fff5e6] to-[#faf8f3] p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-[#2c2c2c] mb-2">
            🏆 今日排行榜
          </h1>
          {todaysChallenge && (
            <p className="text-[#6b6b6b] text-lg">
              {todaysChallenge.theme} - {todaysChallenge.date}
            </p>
          )}
        </motion.div>

        {/* Leaderboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="overflow-hidden shadow-xl border-0 bg-white">
            {topScoresLoading ? (
              <div className="p-8 text-center">
                <div className="inline-block animate-spin">
                  <div className="text-4xl">⏳</div>
                </div>
                <p className="text-[#6b6b6b] mt-4">加载排行榜中...</p>
              </div>
            ) : topScores && topScores.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#ff9a56] to-[#ff8c42] text-white">
                      <th className="px-6 py-4 text-left font-bold">排名</th>
                      <th className="px-6 py-4 text-left font-bold">玩家</th>
                      <th className="px-6 py-4 text-center font-bold">准确率</th>
                      <th className="px-6 py-4 text-center font-bold">得分</th>
                      <th className="px-6 py-4 text-right font-bold">完成时间</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topScores.map((score, index) => (
                      <motion.tr
                        key={score.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className={`border-b border-[#e8e4db] hover:bg-[#f5f1e8] transition-colors ${
                          user?.id === score.userId ? 'bg-[#fff9e6]' : ''
                        }`}
                      >
                        <td className="px-6 py-4">
                          <span className="font-bold text-[#ff9a56]">
                            {score.rank === 1 && '🥇'}
                            {score.rank === 2 && '🥈'}
                            {score.rank === 3 && '🥉'}
                            {score.rank > 3 && `#${score.rank}`}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-semibold text-[#2c2c2c]">
                            {score.userName}
                            {user?.id === score.userId && (
                              <span className="ml-2 text-sm text-[#7ba3d4]">(你)</span>
                            )}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className="font-semibold text-[#2c2c2c]">
                            {score.accuracy}%
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className="font-bold text-[#ff9a56]">
                            {score.score}/{score.totalPhotos}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right text-sm text-[#6b6b6b]">
                          {new Date(score.completedAt).toLocaleTimeString('zh-CN')}
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-8 text-center">
                <div className="text-6xl mb-4">📊</div>
                <p className="text-[#6b6b6b]">暂无排行榜数据</p>
              </div>
            )}
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 flex gap-4 justify-center flex-wrap"
        >
          <Button
            onClick={() => setLocation('/daily-challenge')}
            className="bg-[#ff9a56] hover:bg-[#ff8c42] text-white font-semibold py-3 px-8 rounded-2xl"
          >
            🎮 再来一次
          </Button>

          <Button
            onClick={() => setLocation('/leaderboard')}
            className="bg-[#7ba3d4] hover:bg-[#6b92c3] text-white font-semibold py-3 px-8 rounded-2xl"
          >
            📈 总排行榜
          </Button>

          <Button
            onClick={() => setLocation('/')}
            className="bg-white text-[#2c2c2c] border border-[#e8e4db] hover:bg-[#f5f1e8] font-semibold py-3 px-8 rounded-2xl"
          >
            ← 返回首页
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
