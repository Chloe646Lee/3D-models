/**
 * Game Data & Logic
 * 
 * Design Philosophy: Warm Humanist
 * - Friendly, encouraging feedback
 * - Achievement badges for correct answers
 * - Smooth animations and transitions
 */

export interface Photo {
  id: string;
  imageUrl: string;
  isAI: boolean;
  category: 'landscape' | 'portrait' | 'nature' | 'urban' | 'food';
  description: string;
  sourceExplanation?: string; // 图片来源说明
}

export interface GameState {
  currentPhotoIndex: number;
  score: number;
  totalPhotos: number;
  answers: Answer[];
  isGameOver: boolean;
  selectedAnswer: 'ai' | 'real' | null;
  showResult: boolean;
}

export interface Answer {
  photoId: string;
  userAnswer: 'ai' | 'real';
  isCorrect: boolean;
  timestamp: number;
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  condition: (score: number, totalPhotos: number) => boolean;
}

// New Game photos - from Unsplash + AI generated
export const gamePhotos: Photo[] = [
  // ============ 风景类 ============
  {
    id: 'landscape-ai-1',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_1-LqQ2zpDQrC4SnTPyyfArVY.png',
    isAI: true,
    category: 'landscape',
    description: '金色时刻的山脉风景',
    sourceExplanation: '🤖 AI 生成 - 这是由人工智能生成的图片。通过分析大量真实山脉摄影，AI 学会了如何合成看起来逼真的山景。注意观察：光线分布、云层纹理和山体轮廓可能显示出 AI 生成的特征。',
  },
  {
    id: 'landscape-real-1',
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80',
    isAI: false,
    category: 'landscape',
    description: '真实的山脉摄影',
    sourceExplanation: '📸 真实摄影 - 这是由专业摄影师拍摄的真实山脉风景。来自 Unsplash 的高质量摄影库。真实摄影的特点：自然的光影变化、真实的大气效果、细节丰富且不规则。',
  },
  {
    id: 'landscape-ai-2',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_2-dULoKAuMpP5Fq8ut9jwk6G.webp',
    isAI: true,
    category: 'landscape',
    description: '雾气笼罩的山谷',
    sourceExplanation: '🤖 AI 生成 - 这张图片由 AI 创建，展示了雾气笼罩的山谷景象。AI 生成的雾气效果往往过于均匀或规律，而真实的雾气会有更多的自然变化和不规则性。',
  },
  {
    id: 'landscape-real-2',
    imageUrl: 'https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=800&q=80',
    isAI: false,
    category: 'landscape',
    description: '日出时的风景',
    sourceExplanation: '📸 真实摄影 - 这是真实的日出风景摄影。摄影师捕捉了日出时刻的自然光线变化。真实摄影的特征：光线具有自然的渐变、天空颜色真实多变、细节丰富。',
  },
  {
    id: 'landscape-ai-3',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_3-ZcGXVfM3TxReuicBJMD4Lc.webp',
    isAI: true,
    category: 'landscape',
    description: '樱花盛开的日本花园',
    sourceExplanation: '🤖 AI 生成 - AI 创建的樱花花园场景。AI 在生成重复图案（如花朵）时可能显示出规律性，而真实的自然场景通常更加随机和不规则。',
  },
  {
    id: 'landscape-real-3',
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80',
    isAI: false,
    category: 'landscape',
    description: '宁静的山水风景',
    sourceExplanation: '📸 真实摄影 - 这是真实的山水风景摄影。来自专业摄影师的作品，展现了自然的宁静之美。真实摄影具有自然的色彩还原和丰富的细节层次。',
  },

  // ============ 人物类 ============
  {
    id: 'portrait-ai-1',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_1-Ypo4sMkLDeDs26scNRvNCn.png',
    isAI: true,
    category: 'portrait',
    description: '温暖光线下的人物肖像',
    sourceExplanation: '🤖 AI 生成 - 这是 AI 生成的人物肖像。AI 在生成人脸时可能出现不自然的特征，如眼睛、鼻子或嘴巴的细节不够真实，皮肤纹理过于光滑或规律。',
  },
  {
    id: 'portrait-real-1',
    imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
    isAI: false,
    category: 'portrait',
    description: '真实的人物摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的人物肖像摄影。来自 Unsplash 的专业摄影作品。真实人物摄影具有自然的皮肤纹理、真实的眼神和自然的光影效果。',
  },
  {
    id: 'portrait-ai-2',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_2-hoejJWj4JEcLokijipcdqi.webp',
    isAI: true,
    category: 'portrait',
    description: '专业人物肖像',
    sourceExplanation: '🤖 AI 生成 - AI 创建的专业肖像。注意观察面部特征的对称性和细节的规律性，这些往往是 AI 生成的标志。',
  },
  {
    id: 'portrait-real-2',
    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&q=80',
    isAI: false,
    category: 'portrait',
    description: '微笑的人物肖像',
    sourceExplanation: '📸 真实摄影 - 这是真实的人物摄影。微笑表情自然，眼睛有神，皮肤细节真实可见。真实摄影捕捉了人物的自然气质。',
  },
  {
    id: 'portrait-ai-3',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_3-4VVMkU6RsV59iDY3zowz8A.png',
    isAI: true,
    category: 'portrait',
    description: 'AI 生成的人物肖像',
    sourceExplanation: '🤖 AI 生成 - 这是 AI 生成的人物肖像。AI 生成的人脸通常在细节处理上有所不足，可能出现不自然的面部比例或光影效果。',
  },
  {
    id: 'portrait-real-3',
    imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
    isAI: false,
    category: 'portrait',
    description: '自然光下的人物摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的人物摄影，使用自然光线拍摄。自然光线下的人物摄影具有柔和的光影、真实的肤色和自然的表情。',
  },

  // ============ 自然类 ============
  {
    id: 'nature-ai-1',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_1-cyrtzib2YFRvEoeN4VHA3i.png',
    isAI: true,
    category: 'nature',
    description: '生机勃勃的自然风景',
    sourceExplanation: '🤖 AI 生成 - 这是 AI 生成的自然风景。AI 在生成植物和生物时可能出现不自然的排列或重复图案。',
  },
  {
    id: 'nature-real-1',
    imageUrl: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80',
    isAI: false,
    category: 'nature',
    description: '真实的自然摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的自然风景摄影。来自 Unsplash 的专业摄影作品。真实自然摄影具有丰富的细节、自然的色彩和真实的光影效果。',
  },
  {
    id: 'nature-ai-2',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_2-Y4bYnyUtV6HBfMbeyFmBwA.webp',
    isAI: true,
    category: 'nature',
    description: '充满生命力的植物',
    sourceExplanation: '🤖 AI 生成 - AI 创建的植物场景。注意观察植物的叶脉、纹理和排列方式，AI 生成的植物往往显示出规律性和对称性。',
  },
  {
    id: 'nature-real-2',
    imageUrl: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80',
    isAI: false,
    category: 'nature',
    description: '森林中的自然风景',
    sourceExplanation: '📸 真实摄影 - 这是真实的森林摄影。自然的植物排列、真实的光线穿透、丰富的色彩层次都是真实摄影的特征。',
  },
  {
    id: 'nature-ai-3',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_3-A2ePwB5HaXBeSorxykWVap.webp',
    isAI: true,
    category: 'nature',
    description: '珊瑚礁的水下世界',
    sourceExplanation: '🤖 AI 生成 - AI 创建的水下场景。AI 在生成复杂的水下环境时可能出现不自然的效果，如过度饱和的颜色或不真实的生物形态。',
  },
  {
    id: 'nature-real-3',
    imageUrl: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80',
    isAI: false,
    category: 'nature',
    description: '野生自然风景',
    sourceExplanation: '📸 真实摄影 - 这是真实的野生自然摄影。捕捉了自然界的真实场景，具有丰富的生物多样性和自然的光影效果。',
  },

  // ============ 城市类 ============
  {
    id: 'urban-ai-1',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_1-RWMioSmD3zNzE9tH98dC7D.png',
    isAI: true,
    category: 'urban',
    description: '霓虹灯闪烁的城市街道',
    sourceExplanation: '🤖 AI 生成 - 这是 AI 生成的城市夜景。AI 在生成城市建筑时可能出现不自然的几何形状或过度规律的排列。',
  },
  {
    id: 'urban-real-1',
    imageUrl: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80',
    isAI: false,
    category: 'urban',
    description: '真实的城市摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的城市摄影。来自 Unsplash 的专业摄影作品。真实城市摄影具有自然的建筑细节、真实的光线和自然的城市景观。',
  },
  {
    id: 'urban-ai-2',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_2-k9K9QGqQCZrAU4ZDybg4uM.webp',
    isAI: true,
    category: 'urban',
    description: '现代都市风景',
    sourceExplanation: '🤖 AI 生成 - AI 创建的现代城市场景。注意观察建筑的细节和透视关系，AI 生成的建筑有时会出现不自然的比例或透视错误。',
  },
  {
    id: 'urban-real-2',
    imageUrl: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80',
    isAI: false,
    category: 'urban',
    description: '城市夜景',
    sourceExplanation: '📸 真实摄影 - 这是真实的城市夜景摄影。真实的灯光效果、自然的城市景观和真实的光线反射都是真实摄影的特征。',
  },
  {
    id: 'urban-ai-3',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_3-CdHuGSdrSJz33rf4WsRSZM.webp',
    isAI: true,
    category: 'urban',
    description: '繁华的城市街道',
    sourceExplanation: '🤖 AI 生成 - AI 创建的繁华城市街道。AI 在生成复杂的城市场景时可能出现细节不一致或不自然的人物和物体排列。',
  },
  {
    id: 'urban-real-3',
    imageUrl: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80',
    isAI: false,
    category: 'urban',
    description: '城市建筑摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的城市建筑摄影。捕捉了城市的建筑特色，具有真实的透视、自然的光影和丰富的建筑细节。',
  },

  // ============ 美食类 ============
  {
    id: 'food-ai-1',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_1-LYsaLg6NZqgUsNjBfth7DQ.png',
    isAI: true,
    category: 'food',
    description: '精致的美食摄影',
    sourceExplanation: '🤖 AI 生成 - 这是 AI 生成的美食图片。AI 在生成食物时可能出现不自然的纹理、过度光滑的表面或不真实的食物组合。',
  },
  {
    id: 'food-real-1',
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80',
    isAI: false,
    category: 'food',
    description: '真实的美食摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的美食摄影。来自 Unsplash 的专业美食摄影作品。真实美食摄影具有自然的食物纹理、真实的光影效果和自然的色彩。',
  },
  {
    id: 'food-ai-2',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_2-H4Spr3p55ftxab449Rbap5.webp',
    isAI: true,
    category: 'food',
    description: '米其林星级餐盘',
    sourceExplanation: '🤖 AI 生成 - AI 创建的高级美食图片。注意观察食物的细节和质感，AI 生成的食物往往缺乏真实的纹理和自然的不规则性。',
  },
  {
    id: 'food-real-2',
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80',
    isAI: false,
    category: 'food',
    description: '美味的食物摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的食物摄影。真实的食物具有自然的纹理、真实的光线反射和自然的色彩还原。',
  },
  {
    id: 'food-ai-3',
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_3-hkK3iSVUATgfLcK47zd3ai.png',
    isAI: true,
    category: 'food',
    description: '诱人的美食',
    sourceExplanation: '🤖 AI 生成 - AI 创建的美食图片。AI 在生成食物时可能出现不自然的组合或过度饱和的颜色。',
  },
  {
    id: 'food-real-3',
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80',
    isAI: false,
    category: 'food',
    description: '餐厅美食摄影',
    sourceExplanation: '📸 真实摄影 - 这是真实的餐厅美食摄影。捕捉了食物的真实外观，具有自然的光影、真实的食物质感和专业的摄影技巧。',
  },
];

// Badge definitions
export const BADGES: Badge[] = [
  {
    id: 'first-try',
    name: '初出茅庐',
    icon: '🌱',
    condition: () => true,
  },
  {
    id: 'half-right',
    name: '及格线',
    icon: '📊',
    condition: (score, total) => score >= total * 0.5,
  },
  {
    id: 'good-job',
    name: '不错的成绩',
    icon: '👍',
    condition: (score, total) => score >= total * 0.7,
  },
  {
    id: 'excellent',
    name: '优秀',
    icon: '⭐',
    condition: (score, total) => score >= total * 0.85,
  },
  {
    id: 'perfect',
    name: '完美！',
    icon: '🏆',
    condition: (score, total) => score === total,
  },
];

// Helper functions
export function getEarnedBadges(score: number, totalPhotos: number): Badge[] {
  return BADGES.filter(badge => badge.condition(score, totalPhotos));
}

export function calculateAccuracy(score: number, totalPhotos: number): number {
  return Math.round((score / totalPhotos) * 100);
}

export function getEncouragingMessage(accuracy: number): string {
  if (accuracy === 100) return '🎉 完美！你是 AI 识别大师！';
  if (accuracy >= 85) return '⭐ 太棒了！你的眼光很敏锐！';
  if (accuracy >= 70) return '👍 不错的成绩！继续加油！';
  if (accuracy >= 50) return '📊 还可以，再来一局吧！';
  return '💪 别灰心，多练习就能进步！';
}

export function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
