/**
 * 社交分享功能
 * 支持微信、微博等社交平台
 */

export interface ShareOptions {
  title: string;
  text: string;
  imageUrl?: string;
  url?: string;
}

/**
 * 分享到微信
 * 在微信中，通常通过生成二维码或分享卡片的方式
 */
export function shareToWeChat(options: ShareOptions): void {
  // 微信分享通常需要通过 JSSDK，这里提供一个简化的实现
  // 实际应用中需要集成微信 JSSDK

  const text = encodeURIComponent(options.text);
  const url = encodeURIComponent(options.url || window.location.href);

  // 生成微信分享链接
  const wechatShareUrl = `https://api.weixin.qq.com/sns/oauth2/authorize?appid=YOUR_WECHAT_APPID&redirect_uri=${url}&response_type=code&scope=snsapi_base&state=wechat_share`;

  // 如果在微信环境中，使用 JSSDK
  if ((window as any).wx) {
    (window as any).wx.ready(() => {
      (window as any).wx.onMenuShareAppMessage({
        title: options.title,
        desc: options.text,
        link: options.url || window.location.href,
        imgUrl: options.imageUrl || '',
        type: 'link',
        dataUrl: '',
        success: () => {
          console.log('分享到微信成功');
        },
        cancel: () => {
          console.log('用户取消分享');
        },
      });
    });
  } else {
    // 非微信环境，提示用户
    alert('请在微信中打开此页面进行分享');
  }
}

/**
 * 分享到微博
 */
export function shareToWeibo(options: ShareOptions): void {
  const text = encodeURIComponent(options.text);
  const url = encodeURIComponent(options.url || window.location.href);
  const pic = encodeURIComponent(options.imageUrl || '');

  // 微博分享 API
  const weiboShareUrl = `https://service.weibo.com/share/share.php?url=${url}&title=${text}&pic=${pic}&appkey=YOUR_WEIBO_APPKEY`;

  window.open(weiboShareUrl, '_blank', 'width=600,height=400');
}

/**
 * 分享到 Twitter
 */
export function shareToTwitter(options: ShareOptions): void {
  const text = encodeURIComponent(options.text);
  const url = encodeURIComponent(options.url || window.location.href);

  const twitterShareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`;

  window.open(twitterShareUrl, '_blank', 'width=600,height=400');
}

/**
 * 分享到 Facebook
 */
export function shareToFacebook(options: ShareOptions): void {
  const url = encodeURIComponent(options.url || window.location.href);

  const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;

  window.open(facebookShareUrl, '_blank', 'width=600,height=400');
}

/**
 * 复制到剪贴板
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      // 降级方案
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      return true;
    }
  } catch (error) {
    console.error('Failed to copy to clipboard:', error);
    return false;
  }
}

/**
 * 生成分享链接
 */
export function generateShareLink(
  baseUrl: string,
  params: Record<string, string>
): string {
  const url = new URL(baseUrl);
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.append(key, value);
  });
  return url.toString();
}

/**
 * 检查是否在微信中
 */
export function isInWeChat(): boolean {
  const ua = navigator.userAgent.toLowerCase();
  return /micromessenger/.test(ua);
}

/**
 * 检查是否在微博中
 */
export function isInWeibo(): boolean {
  const ua = navigator.userAgent.toLowerCase();
  return /weibo/.test(ua);
}

/**
 * 获取分享文案
 */
export function getShareText(
  score: number,
  totalPhotos: number,
  accuracy: number,
  achievements: string[] = []
): string {
  const achievementEmojis = achievements.join('');
  return `🎮 我在 AI vs 真实摄影挑战中得分 ${score}/${totalPhotos}，准确率 ${accuracy.toFixed(1)}%！ ${achievementEmojis} #AI识别挑战 #摄影`;
}
