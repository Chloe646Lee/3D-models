/**
 * 成就徽章系统
 * 根据用户的表现自动解锁不同的成就徽章
 */

export type AchievementType =
  | 'perfect_score'
  | 'high_accuracy'
  | 'streak_3'
  | 'streak_7'
  | 'streak_30'
  | 'first_play'
  | 'daily_warrior'
  | 'theme_master'
  | 'detective'
  | 'legend';

export interface Achievement {
  id: AchievementType;
  name: string;
  description: string;
  icon: string;
  emoji: string;
  requirement: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
}

export const ACHIEVEMENTS: Record<AchievementType, Achievement> = {
  perfect_score: {
    id: 'perfect_score',
    name: '完美得分',
    description: '在一次挑战中获得 100% 的准确率',
    icon: '⭐',
    emoji: '✨',
    requirement: '准确率 = 100%',
    rarity: 'epic',
  },
  high_accuracy: {
    id: 'high_accuracy',
    name: '高手',
    description: '在一次挑战中获得 90% 以上的准确率',
    icon: '🎯',
    emoji: '🎯',
    requirement: '准确率 ≥ 90%',
    rarity: 'rare',
  },
  streak_3: {
    id: 'streak_3',
    name: '连胜 3 天',
    description: '连续 3 天参加每日挑战',
    icon: '🔥',
    emoji: '🔥',
    requirement: '连续 3 天',
    rarity: 'uncommon',
  },
  streak_7: {
    id: 'streak_7',
    name: '连胜 7 天',
    description: '连续 7 天参加每日挑战',
    icon: '🌟',
    emoji: '🌟',
    requirement: '连续 7 天',
    rarity: 'rare',
  },
  streak_30: {
    id: 'streak_30',
    name: '月度冠军',
    description: '连续 30 天参加每日挑战',
    icon: '👑',
    emoji: '👑',
    requirement: '连续 30 天',
    rarity: 'legendary',
  },
  first_play: {
    id: 'first_play',
    name: '初次体验',
    description: '完成第一次挑战',
    icon: '🎮',
    emoji: '🎮',
    requirement: '完成 1 次挑战',
    rarity: 'common',
  },
  daily_warrior: {
    id: 'daily_warrior',
    name: '每日勇士',
    description: '完成 10 次每日挑战',
    icon: '⚔️',
    emoji: '⚔️',
    requirement: '完成 10 次每日挑战',
    rarity: 'uncommon',
  },
  theme_master: {
    id: 'theme_master',
    name: '主题大师',
    description: '在所有 5 个主题中都获得过高分',
    icon: '🎨',
    emoji: '🎨',
    requirement: '所有主题准确率 ≥ 80%',
    rarity: 'rare',
  },
  detective: {
    id: 'detective',
    name: '侦探',
    description: '连续 5 次正确识别 AI 生成的图片',
    icon: '🔍',
    emoji: '🔍',
    requirement: '连续 5 次正确',
    rarity: 'uncommon',
  },
  legend: {
    id: 'legend',
    name: '传奇玩家',
    description: '在排行榜上进入前 10',
    icon: '🏆',
    emoji: '🏆',
    requirement: '排行榜前 10',
    rarity: 'legendary',
  },
};

export interface ShareData {
  score: number;
  totalPhotos: number;
  accuracy: number;
  achievements: AchievementType[];
  date: string;
  theme?: string;
}

/**
 * 根据得分计算用户解锁的成就
 */
export function calculateAchievements(
  score: number,
  totalPhotos: number,
  streak: number = 0,
  dailyChallengeCount: number = 0,
  allThemesScores: Record<string, number> = {}
): AchievementType[] {
  const achievements: AchievementType[] = [];
  const accuracy = (score / totalPhotos) * 100;

  // 首次完成
  if (dailyChallengeCount === 1) {
    achievements.push('first_play');
  }

  // 完美得分
  if (accuracy === 100) {
    achievements.push('perfect_score');
  }

  // 高手
  if (accuracy >= 90) {
    achievements.push('high_accuracy');
  }

  // 连胜
  if (streak >= 30) {
    achievements.push('streak_30');
  } else if (streak >= 7) {
    achievements.push('streak_7');
  } else if (streak >= 3) {
    achievements.push('streak_3');
  }

  // 每日勇士
  if (dailyChallengeCount >= 10) {
    achievements.push('daily_warrior');
  }

  // 主题大师
  const themeCount = Object.values(allThemesScores).length;
  const allThemesHighScore = Object.values(allThemesScores).every(s => s >= 80);
  if (themeCount === 5 && allThemesHighScore) {
    achievements.push('theme_master');
  }

  // 侦探（这个需要追踪连续正确的 AI 识别）
  // 在实际实现中需要从数据库查询

  return achievements;
}

/**
 * 生成分享文案
 */
export function generateShareText(data: ShareData): string {
  const accuracy = data.accuracy.toFixed(1);
  const achievementEmojis = data.achievements
    .map(id => ACHIEVEMENTS[id]?.emoji || '')
    .join('');

  return `🎮 我在 AI vs 真实摄影挑战中得分 ${data.score}/${data.totalPhotos}，准确率 ${accuracy}%！ ${achievementEmojis} #AI识别挑战 #摄影`;
}

/**
 * 获取成就的稀有度颜色
 */
export function getRarityColor(rarity: Achievement['rarity']): string {
  const colors: Record<Achievement['rarity'], string> = {
    common: '#95a5a6',
    uncommon: '#2ecc71',
    rare: '#3498db',
    epic: '#9b59b6',
    legendary: '#f39c12',
  };
  return colors[rarity];
}

/**
 * 获取成就的稀有度标签
 */
export function getRarityLabel(rarity: Achievement['rarity']): string {
  const labels: Record<Achievement['rarity'], string> = {
    common: '普通',
    uncommon: '不常见',
    rare: '稀有',
    epic: '史诗',
    legendary: '传奇',
  };
  return labels[rarity];
}
