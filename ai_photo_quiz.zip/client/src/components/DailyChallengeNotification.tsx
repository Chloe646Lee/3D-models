/**
 * Daily Challenge Notification Component
 * Displays a toast notification when a new daily challenge is published
 */

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X } from 'lucide-react';

export interface NotificationData {
  id: string;
  title: string;
  message: string;
  type: 'challenge' | 'achievement' | 'info';
  timestamp: number;
}

interface DailyChallengeNotificationProps {
  notifications: NotificationData[];
  onDismiss: (id: string) => void;
}

export function DailyChallengeNotification({
  notifications,
  onDismiss,
}: DailyChallengeNotificationProps) {
  return (
    <AnimatePresence>
      <div className="fixed top-4 right-4 z-50 space-y-3 pointer-events-none">
        {notifications.map((notification) => (
          <motion.div
            key={notification.id}
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="pointer-events-auto"
          >
            <NotificationCard
              notification={notification}
              onDismiss={() => onDismiss(notification.id)}
            />
          </motion.div>
        ))}
      </div>
    </AnimatePresence>
  );
}

interface NotificationCardProps {
  notification: NotificationData;
  onDismiss: () => void;
}

function NotificationCard({ notification, onDismiss }: NotificationCardProps) {
  const [isVisible, setIsVisible] = useState(true);

  // Auto-dismiss after 6 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onDismiss, 300);
    }, 6000);

    return () => clearTimeout(timer);
  }, [onDismiss]);

  const getBackgroundColor = () => {
    switch (notification.type) {
      case 'challenge':
        return 'bg-gradient-to-r from-orange-50 to-amber-50 border-orange-200';
      case 'achievement':
        return 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-200';
      case 'info':
        return 'bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200';
      default:
        return 'bg-gradient-to-r from-gray-50 to-slate-50 border-gray-200';
    }
  };

  const getIconColor = () => {
    switch (notification.type) {
      case 'challenge':
        return 'text-orange-500';
      case 'achievement':
        return 'text-green-500';
      case 'info':
        return 'text-blue-500';
      default:
        return 'text-gray-500';
    }
  };

  const getTextColor = () => {
    switch (notification.type) {
      case 'challenge':
        return 'text-orange-900';
      case 'achievement':
        return 'text-green-900';
      case 'info':
        return 'text-blue-900';
      default:
        return 'text-gray-900';
    }
  };

  return (
    <div
      className={`
        ${getBackgroundColor()}
        border rounded-lg shadow-lg p-4 max-w-sm
        backdrop-blur-sm
        transition-all duration-300
        ${isVisible ? 'opacity-100' : 'opacity-0'}
      `}
    >
      <div className="flex items-start gap-3">
        <div className={`flex-shrink-0 mt-0.5 ${getIconColor()}`}>
          <Bell size={20} />
        </div>

        <div className="flex-1 min-w-0">
          <h3 className={`font-semibold text-sm ${getTextColor()}`}>
            {notification.title}
          </h3>
          <p className={`text-sm mt-1 ${getTextColor()} opacity-80`}>
            {notification.message}
          </p>
        </div>

        <button
          onClick={onDismiss}
          className={`flex-shrink-0 ${getTextColor()} opacity-50 hover:opacity-100 transition-opacity`}
        >
          <X size={18} />
        </button>
      </div>

      {/* Progress bar */}
      <motion.div
        initial={{ scaleX: 1 }}
        animate={{ scaleX: 0 }}
        transition={{ duration: 6, ease: 'linear' }}
        className={`h-1 mt-3 rounded-full origin-left ${
          notification.type === 'challenge'
            ? 'bg-orange-300'
            : notification.type === 'achievement'
            ? 'bg-green-300'
            : 'bg-blue-300'
        }`}
      />
    </div>
  );
}

/**
 * Hook to manage notifications
 */
export function useNotifications() {
  const [notifications, setNotifications] = useState<NotificationData[]>([]);

  const addNotification = (
    title: string,
    message: string,
    type: 'challenge' | 'achievement' | 'info' = 'info'
  ) => {
    const id = `${Date.now()}-${Math.random()}`;
    const notification: NotificationData = {
      id,
      title,
      message,
      type,
      timestamp: Date.now(),
    };

    setNotifications((prev) => [...prev, notification]);
    return id;
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return {
    notifications,
    addNotification,
    dismissNotification,
  };
}
