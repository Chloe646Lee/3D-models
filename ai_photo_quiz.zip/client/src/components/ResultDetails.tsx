import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';
import type { Photo, Answer } from '@/lib/gameData';
import ImageMagnifier from '@/components/ImageMagnifier';
import AIFeatureHints from '@/components/AIFeatureHints';

interface ResultDetailsProps {
  photos: Photo[];
  answers: Answer[];
  onClose?: () => void;
}

export default function ResultDetails({ photos, answers, onClose }: ResultDetailsProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpanded = (photoId: string) => {
    setExpandedId(expandedId === photoId ? null : photoId);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-[#2c2c2c] mb-2">📋 详细答题回顾</h2>
        <p className="text-[#6b6b6b]">点击每张图片查看详细说明</p>
      </div>

      <div className="space-y-3">
        {photos.map((photo, index) => {
          const answer = answers.find(a => a.photoId === photo.id);
          const isExpanded = expandedId === photo.id;
          const isCorrect = answer?.isCorrect ?? false;

          return (
            <motion.div
              key={photo.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card
                className={`p-4 cursor-pointer transition-all ${
                  isCorrect
                    ? 'border-[#ff9a56] bg-[#fff9f3]'
                    : 'border-[#ff6b6b] bg-[#fff5f5]'
                }`}
                onClick={() => toggleExpanded(photo.id)}
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">
                        {isCorrect ? '✅' : '❌'}
                      </span>
                      <div>
                        <p className="font-semibold text-[#2c2c2c]">
                          第 {index + 1} 题 - {photo.category}
                        </p>
                        <p className="text-sm text-[#6b6b6b]">
                          {photo.description}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-[#ff9a56]">
                      {photo.isAI ? '🤖 AI' : '📸 真实'}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-[#ff9a56]" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-[#ff9a56]" />
                    )}
                  </div>
                </div>

                {/* Your Answer */}
                <div className="mt-3 pt-3 border-t border-[#ffe4cc]">
                  <p className="text-sm text-[#6b6b6b]">
                    <span className="font-medium">你的答案：</span>{' '}
                    <span className={answer?.userAnswer === 'ai' ? 'text-[#ff9a56]' : 'text-[#7ba3d4]'}>
                      {answer?.userAnswer === 'ai' ? '🤖 AI 生成' : '📸 真实摄影'}
                    </span>
                  </p>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 pt-4 border-t border-[#ffe4cc]"
                  >
                    {/* Image Preview with Magnifier */}
                    <div className="mb-4">
                      <ImageMagnifier
                        imageUrl={photo.imageUrl}
                        alt={photo.description}
                        magnifierHeight={250}
                        magnifierWidth={250}
                        zoomLevel={2.5}
                      />
                    </div>

                    {/* Source Explanation */}
                    {photo.sourceExplanation && (
                      <div className="bg-white rounded-lg p-3 mb-3">
                        <p className="text-sm text-[#2c2c2c] leading-relaxed">
                          {photo.sourceExplanation}
                        </p>
                      </div>
                    )}

                    {/* Verdict */}
                    <div className={`rounded-lg p-3 ${
                      isCorrect
                        ? 'bg-[#e8f5e9] border border-[#4caf50]'
                        : 'bg-[#ffebee] border border-[#f44336]'
                    }`}>
                      <p className="text-sm font-medium">
                        {isCorrect ? (
                          <span className="text-[#2e7d32]">✓ 回答正确！</span>
                        ) : (
                          <span className="text-[#c62828]">✗ 回答错误</span>
                        )}
                      </p>
                      {!isCorrect && (
                        <p className="text-xs text-[#6b6b6b] mt-1">
                          正确答案是：{photo.isAI ? '🤖 AI 生成' : '📸 真实摄影'}
                        </p>
                      )}
                    </div>

                    {/* AI Feature Hints */}
                    <AIFeatureHints isAI={photo.isAI} />
                  </motion.div>
                )}
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Close Button */}
      {onClose && (
        <div className="mt-6 flex justify-center">
          <Button
            onClick={onClose}
            className="bg-[#ff9a56] hover:bg-[#ff8a3d] text-white px-6 py-2 rounded-full"
          >
            关闭详情
          </Button>
        </div>
      )}
    </div>
  );
}
