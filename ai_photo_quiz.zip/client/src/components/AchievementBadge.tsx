import { motion } from 'framer-motion';
import { ACHIEVEMENTS, getRarityColor, getRarityLabel, type AchievementType } from '@/lib/achievements';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface AchievementBadgeProps {
  achievementId: AchievementType;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  unlocked?: boolean;
}

export default function AchievementBadge({
  achievementId,
  size = 'md',
  showLabel = false,
  unlocked = true,
}: AchievementBadgeProps) {
  const achievement = ACHIEVEMENTS[achievementId];
  if (!achievement) return null;

  const sizeClasses = {
    sm: 'w-12 h-12 text-lg',
    md: 'w-16 h-16 text-2xl',
    lg: 'w-20 h-20 text-4xl',
  };

  const rarityColor = getRarityColor(achievement.rarity);
  const rarityLabel = getRarityLabel(achievement.rarity);

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <motion.div
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center cursor-pointer transition-all ${
            unlocked
              ? 'bg-gradient-to-br shadow-lg'
              : 'bg-gray-300 opacity-50'
          }`}
          style={
            unlocked
              ? {
                  backgroundImage: `linear-gradient(135deg, ${rarityColor}20, ${rarityColor}40)`,
                  border: `2px solid ${rarityColor}`,
                }
              : undefined
          }
        >
          <span className={unlocked ? 'drop-shadow-lg' : 'grayscale'}>
            {achievement.emoji}
          </span>

          {/* Lock Icon for Locked Achievements */}
          {!unlocked && (
            <div className="absolute -bottom-1 -right-1 bg-gray-500 rounded-full w-4 h-4 flex items-center justify-center text-white text-xs">
              🔒
            </div>
          )}
        </motion.div>
      </TooltipTrigger>

      <TooltipContent className="max-w-xs">
        <div className="space-y-1">
          <p className="font-semibold text-white">{achievement.name}</p>
          <p className="text-xs text-gray-200">{achievement.description}</p>
          <p className="text-xs text-gray-300">
            <span
              className="inline-block px-2 py-0.5 rounded text-white"
              style={{ backgroundColor: rarityColor }}
            >
              {rarityLabel}
            </span>
          </p>
          {!unlocked && (
            <p className="text-xs text-yellow-200 mt-2">
              需要：{achievement.requirement}
            </p>
          )}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
