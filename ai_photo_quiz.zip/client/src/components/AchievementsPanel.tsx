import { motion } from 'framer-motion';
import { ACHIEVEMENTS, type AchievementType } from '@/lib/achievements';
import AchievementBadge from '@/components/AchievementBadge';

interface AchievementsPanelProps {
  unlockedAchievements: AchievementType[];
  totalAchievements?: number;
  showLocked?: boolean;
}

export default function AchievementsPanel({
  unlockedAchievements,
  totalAchievements = Object.keys(ACHIEVEMENTS).length,
  showLocked = true,
}: AchievementsPanelProps) {
  const allAchievementIds = Object.keys(ACHIEVEMENTS) as AchievementType[];
  const lockedAchievements = allAchievementIds.filter(
    id => !unlockedAchievements.includes(id)
  );

  const progressPercentage = (unlockedAchievements.length / totalAchievements) * 100;

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-bold text-[#2c2c2c]">🏆 成就徽章</h3>
          <span className="text-sm text-[#6b6b6b]">
            {unlockedAchievements.length} / {totalAchievements}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progressPercentage}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="h-full bg-gradient-to-r from-[#ff9a56] to-[#ff6b6b]"
          />
        </div>
      </div>

      {/* Unlocked Achievements */}
      {unlockedAchievements.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h4 className="text-sm font-semibold text-[#2c2c2c] mb-3">已解锁</h4>
          <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
            {unlockedAchievements.map((achievementId, index) => (
              <motion.div
                key={achievementId}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <AchievementBadge
                  achievementId={achievementId}
                  size="md"
                  unlocked={true}
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Locked Achievements */}
      {showLocked && lockedAchievements.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h4 className="text-sm font-semibold text-[#6b6b6b] mb-3">未解锁</h4>
          <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
            {lockedAchievements.map((achievementId, index) => (
              <motion.div
                key={achievementId}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 + index * 0.02 }}
              >
                <AchievementBadge
                  achievementId={achievementId}
                  size="md"
                  unlocked={false}
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Empty State */}
      {unlockedAchievements.length === 0 && (
        <div className="text-center py-8">
          <p className="text-[#6b6b6b] text-sm">
            开始挑战来解锁成就徽章吧！ 🚀
          </p>
        </div>
      )}
    </div>
  );
}
