import { motion } from 'framer-motion';
import { AlertCircle, Lightbulb } from 'lucide-react';

interface AIFeatureHintsProps {
  isAI: boolean;
}

export default function AIFeatureHints({ isAI }: AIFeatureHintsProps) {
  const hints = isAI
    ? [
        {
          title: '光线过于均匀',
          description: 'AI 生成的光线往往分布得过于规律和均匀，缺乏真实摄影中的自然变化。',
          icon: '💡',
        },
        {
          title: '纹理规律性强',
          description: '观察皮肤、布料、植物等纹理，AI 生成的纹理往往显示出重复的图案和规律性。',
          icon: '🔄',
        },
        {
          title: '细节不够自然',
          description: '放大查看细节部分，AI 生成的细节往往过于光滑、缺乏真实的随机性和复杂性。',
          icon: '🔍',
        },
        {
          title: '边界处理不自然',
          description: '观察物体与背景的边界，AI 生成的边界有时会出现模糊或不自然的过渡。',
          icon: '🎯',
        },
        {
          title: '色彩过度饱和',
          description: 'AI 生成的图片色彩有时过于鲜艳和饱和，与真实摄影的自然色彩不符。',
          icon: '🎨',
        },
      ]
    : [
        {
          title: '自然的光影变化',
          description: '真实摄影的光线具有自然的渐变和变化，反映了真实的光学特性。',
          icon: '☀️',
        },
        {
          title: '随机的纹理细节',
          description: '真实物体的纹理具有随机性和复杂性，不会出现规律的重复图案。',
          icon: '✨',
        },
        {
          title: '丰富的细节层次',
          description: '真实摄影包含丰富的细节信息，即使放大后也能看到真实的微观结构。',
          icon: '📷',
        },
        {
          title: '自然的边界过渡',
          description: '真实摄影中物体与背景的边界自然过渡，没有生硬的分割。',
          icon: '🌊',
        },
        {
          title: '真实的色彩还原',
          description: '真实摄影的色彩还原自然真实，反映了拍摄时的真实光线条件。',
          icon: '🌈',
        },
      ];

  return (
    <div className="mt-4 space-y-2">
      <div className="flex items-center gap-2 mb-3">
        <Lightbulb className="w-5 h-5 text-[#ff9a56]" />
        <h4 className="font-semibold text-[#2c2c2c]">
          {isAI ? '🤖 AI 生成特征' : '📸 真实摄影特征'}
        </h4>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {hints.map((hint, index) => (
          <motion.div
            key={hint.title}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`p-3 rounded-lg border ${
              isAI
                ? 'bg-[#fff5f5] border-[#ff6b6b]/30'
                : 'bg-[#f0f7ff] border-[#7ba3d4]/30'
            }`}
          >
            <div className="flex items-start gap-2">
              <span className="text-lg flex-shrink-0">{hint.icon}</span>
              <div className="flex-1">
                <p className="text-sm font-medium text-[#2c2c2c]">
                  {hint.title}
                </p>
                <p className="text-xs text-[#6b6b6b] mt-1">
                  {hint.description}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Pro Tip */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-3 p-3 bg-[#fff9f3] border border-[#ffe4cc] rounded-lg flex items-start gap-2"
      >
        <AlertCircle className="w-4 h-4 text-[#ff9a56] flex-shrink-0 mt-0.5" />
        <p className="text-xs text-[#6b6b6b]">
          <strong>专业提示：</strong>使用放大镜功能仔细观察图片细节，结合上述特征提示，能更准确地识别 AI 生成的图片。
        </p>
      </motion.div>
    </div>
  );
}
