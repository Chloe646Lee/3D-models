import { motion } from 'framer-motion';
import { useRef } from 'react';
import html2canvas from 'html2canvas';
import { ACHIEVEMENTS, type AchievementType } from '@/lib/achievements';
import AchievementBadge from '@/components/AchievementBadge';

interface ShareCardProps {
  score: number;
  totalPhotos: number;
  accuracy: number;
  achievements: AchievementType[];
  date?: string;
  theme?: string;
}

export default function ShareCard({
  score,
  totalPhotos,
  accuracy,
  achievements,
  date = new Date().toLocaleDateString('zh-CN'),
  theme,
}: ShareCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  const generateImage = async () => {
    if (!cardRef.current) return;

    try {
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: '#faf8f3',
        scale: 2,
        logging: false,
      });

      return canvas.toDataURL('image/png');
    } catch (error) {
      console.error('Failed to generate share image:', error);
      return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Share Card Preview */}
      <motion.div
        ref={cardRef}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md mx-auto p-6 rounded-2xl bg-gradient-to-br from-[#fff9f3] to-[#ffe4cc] border-2 border-[#ff9a56] shadow-xl"
      >
        {/* Header */}
        <div className="text-center mb-6">
          <h2 className="text-3xl font-bold text-[#2c2c2c] mb-2">
            🎮 AI vs 真实摄影
          </h2>
          <p className="text-[#6b6b6b]">挑战成绩分享</p>
        </div>

        {/* Score Section */}
        <div className="bg-white rounded-xl p-4 mb-4 shadow-sm">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-[#ff9a56]">{score}</p>
              <p className="text-xs text-[#6b6b6b]">得分</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-[#7ba3d4]">{accuracy.toFixed(1)}%</p>
              <p className="text-xs text-[#6b6b6b]">准确率</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-[#ff6b6b]">{totalPhotos}</p>
              <p className="text-xs text-[#6b6b6b]">总题数</p>
            </div>
          </div>
        </div>

        {/* Theme */}
        {theme && (
          <div className="text-center mb-4">
            <span className="inline-block px-3 py-1 bg-[#ff9a56]/20 text-[#ff9a56] rounded-full text-sm font-medium">
              📌 {theme}
            </span>
          </div>
        )}

        {/* Achievements */}
        {achievements.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-semibold text-[#2c2c2c] text-center mb-3">
              🏆 已解锁成就
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {achievements.map(achievementId => (
                <div key={achievementId} className="flex items-center gap-1">
                  <AchievementBadge
                    achievementId={achievementId}
                    size="sm"
                    unlocked={true}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Date */}
        <div className="text-center text-xs text-[#6b6b6b] pt-4 border-t border-[#ffe4cc]">
          {date}
        </div>

        {/* Watermark */}
        <div className="text-center text-xs text-[#6b6b6b]/50 mt-2">
          分享自 AI vs 真实摄影挑战
        </div>
      </motion.div>

      {/* Action Buttons */}
      <div className="flex gap-3 justify-center">
        <button
          onClick={async () => {
            const imageUrl = await generateImage();
            if (imageUrl) {
              // 复制到剪贴板
              const link = document.createElement('a');
              link.href = imageUrl;
              link.download = `ai-photo-quiz-${Date.now()}.png`;
              link.click();
            }
          }}
          className="px-4 py-2 bg-[#ff9a56] hover:bg-[#ff8a3d] text-white rounded-lg font-medium transition-colors"
        >
          📥 下载分享卡片
        </button>
      </div>
    </div>
  );
}
