import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ZoomIn, ZoomOut, X } from 'lucide-react';

interface ImageMagnifierProps {
  imageUrl: string;
  alt: string;
  magnifierHeight?: number;
  magnifierWidth?: number;
  zoomLevel?: number;
}

export default function ImageMagnifier({
  imageUrl,
  alt,
  magnifierHeight = 200,
  magnifierWidth = 200,
  zoomLevel = 2.5,
}: ImageMagnifierProps) {
  const [showMagnifier, setShowMagnifier] = useState(false);
  const [magnifierPosition, setMagnifierPosition] = useState({ x: 0, y: 0 });
  const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 });
  const imgRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const img = imgRef.current;
    if (!img) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!showMagnifier || !containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      setMagnifierPosition({ x, y });

      // Calculate image position for the magnified view
      const imgRect = img.getBoundingClientRect();
      const offsetX = (x / rect.width) * img.naturalWidth;
      const offsetY = (y / rect.height) * img.naturalHeight;

      setImagePosition({
        x: -offsetX * zoomLevel + magnifierWidth / 2,
        y: -offsetY * zoomLevel + magnifierHeight / 2,
      });
    };

    const handleMouseLeave = () => {
      setShowMagnifier(false);
    };

    if (containerRef.current) {
      containerRef.current.addEventListener('mousemove', handleMouseMove);
      containerRef.current.addEventListener('mouseleave', handleMouseLeave);
    }

    return () => {
      if (containerRef.current) {
        containerRef.current.removeEventListener('mousemove', handleMouseMove);
        containerRef.current.removeEventListener('mouseleave', handleMouseLeave);
      }
    };
  }, [showMagnifier, zoomLevel, magnifierHeight, magnifierWidth]);

  return (
    <div className="w-full">
      {/* Main Image Container */}
      <div
        ref={containerRef}
        className="relative w-full rounded-lg overflow-hidden bg-gray-100 cursor-crosshair"
        onMouseEnter={() => setShowMagnifier(true)}
        onMouseLeave={() => setShowMagnifier(false)}
      >
        <img
          ref={imgRef}
          src={imageUrl}
          alt={alt}
          className="w-full h-auto block"
        />

        {/* Magnifier Lens */}
        {showMagnifier && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute border-2 border-[#ff9a56] rounded-full pointer-events-none bg-white shadow-lg overflow-hidden"
            style={{
              width: `${magnifierWidth}px`,
              height: `${magnifierHeight}px`,
              left: `${magnifierPosition.x - magnifierWidth / 2}px`,
              top: `${magnifierPosition.y - magnifierHeight / 2}px`,
            }}
          >
            {/* Magnified Image */}
            <img
              src={imageUrl}
              alt={`${alt} - magnified`}
              className="absolute"
              style={{
                width: `${(imgRef.current?.naturalWidth || 0) * zoomLevel}px`,
                height: `${(imgRef.current?.naturalHeight || 0) * zoomLevel}px`,
                left: `${imagePosition.x}px`,
                top: `${imagePosition.y}px`,
              }}
            />

            {/* Crosshair */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-1/2 left-1/2 w-4 h-0.5 bg-[#ff9a56] transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute top-1/2 left-1/2 w-0.5 h-4 bg-[#ff9a56] transform -translate-x-1/2 -translate-y-1/2" />
            </div>
          </motion.div>
        )}

        {/* Zoom Hint */}
        {!showMagnifier && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.7 }}
            className="absolute top-3 right-3 bg-black/50 text-white px-3 py-2 rounded-lg text-sm flex items-center gap-2"
          >
            <ZoomIn className="w-4 h-4" />
            悬停放大
          </motion.div>
        )}
      </div>

      {/* Info Box */}
      <div className="mt-3 bg-[#fff9f3] border border-[#ffe4cc] rounded-lg p-3">
        <p className="text-xs text-[#6b6b6b] flex items-start gap-2">
          <span className="text-lg">💡</span>
          <span>
            <strong>放大镜提示：</strong>将鼠标悬停在图片上查看放大细节。注意观察：
            <br />
            • AI 生成的图片：光线过于均匀、纹理规律、细节重复
            <br />
            • 真实摄影：自然的光影变化、随机的纹理、丰富的细节层次
          </span>
        </p>
      </div>
    </div>
  );
}
