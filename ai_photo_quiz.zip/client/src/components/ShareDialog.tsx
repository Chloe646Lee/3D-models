import { motion, AnimatePresence } from 'framer-motion';
import { X, Copy, Share2 } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import ShareCard from '@/components/ShareCard';
import AchievementsPanel from '@/components/AchievementsPanel';
import { generateShareText, type AchievementType } from '@/lib/achievements';
import { copyToClipboard, shareToWeibo, shareToTwitter } from '@/lib/socialShare';
import { toast } from 'sonner';

interface ShareDialogProps {
  isOpen: boolean;
  onClose: () => void;
  score: number;
  totalPhotos: number;
  accuracy: number;
  achievements: AchievementType[];
  date?: string;
  theme?: string;
}

export default function ShareDialog({
  isOpen,
  onClose,
  score,
  totalPhotos,
  accuracy,
  achievements,
  date,
  theme,
}: ShareDialogProps) {
  const [copied, setCopied] = useState(false);
  const shareText = generateShareText({
    score,
    totalPhotos,
    accuracy,
    achievements,
    date: date || new Date().toLocaleDateString('zh-CN'),
    theme,
  });

  const handleCopyText = async () => {
    const success = await copyToClipboard(shareText);
    if (success) {
      setCopied(true);
      toast.success('已复制到剪贴板！');
      setTimeout(() => setCopied(false), 2000);
    } else {
      toast.error('复制失败，请重试');
    }
  };

  const handleShareWeibo = () => {
    shareToWeibo({
      title: '我的 AI vs 真实摄影挑战成绩',
      text: shareText,
      url: window.location.href,
    });
  };

  const handleShareTwitter = () => {
    shareToTwitter({
      title: '我的 AI vs 真实摄影挑战成绩',
      text: shareText,
      url: window.location.href,
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-40"
          />

          {/* Dialog */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white rounded-2xl shadow-2xl"
          >
            {/* Header */}
            <div className="sticky top-0 flex items-center justify-between p-6 border-b border-[#ffe4cc] bg-white rounded-t-2xl">
              <h2 className="text-2xl font-bold text-[#2c2c2c]">📤 分享成绩</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-[#6b6b6b]" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              {/* Share Card Preview */}
              <div>
                <h3 className="text-lg font-semibold text-[#2c2c2c] mb-4">
                  📸 分享卡片预览
                </h3>
                <ShareCard
                  score={score}
                  totalPhotos={totalPhotos}
                  accuracy={accuracy}
                  achievements={achievements}
                  date={date}
                  theme={theme}
                />
              </div>

              {/* Achievements */}
              {achievements.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-[#2c2c2c] mb-4">
                    🏆 已解锁成就
                  </h3>
                  <AchievementsPanel
                    unlockedAchievements={achievements}
                    showLocked={false}
                  />
                </div>
              )}

              {/* Share Text */}
              <div>
                <h3 className="text-lg font-semibold text-[#2c2c2c] mb-3">
                  📝 分享文案
                </h3>
                <div className="bg-[#f5f5f5] rounded-lg p-4 mb-3">
                  <p className="text-[#2c2c2c] text-sm break-words">
                    {shareText}
                  </p>
                </div>
                <button
                  onClick={handleCopyText}
                  className={`w-full px-4 py-2 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
                    copied
                      ? 'bg-green-100 text-green-700'
                      : 'bg-[#ff9a56] hover:bg-[#ff8a3d] text-white'
                  }`}
                >
                  <Copy className="w-4 h-4" />
                  {copied ? '已复制！' : '复制文案'}
                </button>
              </div>

              {/* Social Share Buttons */}
              <div>
                <h3 className="text-lg font-semibold text-[#2c2c2c] mb-3">
                  🌐 分享到社交平台
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {/* WeChat */}
                  <button
                    onClick={() => {
                      toast.info('请在微信中打开此页面进行分享');
                    }}
                    className="p-4 rounded-lg bg-[#09b83e] hover:bg-[#08a835] text-white font-medium transition-colors flex flex-col items-center gap-2"
                  >
                    <span className="text-2xl">💬</span>
                    <span className="text-xs">微信</span>
                  </button>

                  {/* Weibo */}
                  <button
                    onClick={handleShareWeibo}
                    className="p-4 rounded-lg bg-[#e6162d] hover:bg-[#d41a1f] text-white font-medium transition-colors flex flex-col items-center gap-2"
                  >
                    <span className="text-2xl">🐦</span>
                    <span className="text-xs">微博</span>
                  </button>

                  {/* Twitter */}
                  <button
                    onClick={handleShareTwitter}
                    className="p-4 rounded-lg bg-[#1da1f2] hover:bg-[#1a91da] text-white font-medium transition-colors flex flex-col items-center gap-2"
                  >
                    <span className="text-2xl">𝕏</span>
                    <span className="text-xs">Twitter</span>
                  </button>

                  {/* Copy Link */}
                  <button
                    onClick={handleCopyText}
                    className="p-4 rounded-lg bg-[#7ba3d4] hover:bg-[#6b93c4] text-white font-medium transition-colors flex flex-col items-center gap-2"
                  >
                    <span className="text-2xl">🔗</span>
                    <span className="text-xs">复制链接</span>
                  </button>
                </div>
              </div>

              {/* Info */}
              <div className="bg-[#fff9f3] border border-[#ffe4cc] rounded-lg p-4">
                <p className="text-sm text-[#6b6b6b]">
                  💡 <strong>提示：</strong>
                  在微信中，您可以直接分享此页面到朋友圈或群聊。在其他平台，点击对应按钮即可分享。
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 flex gap-3 p-6 border-t border-[#ffe4cc] bg-white rounded-b-2xl">
              <Button
                onClick={onClose}
                variant="outline"
                className="flex-1"
              >
                关闭
              </Button>
              <Button
                onClick={handleCopyText}
                className="flex-1 bg-[#ff9a56] hover:bg-[#ff8a3d] text-white"
              >
                <Share2 className="w-4 h-4 mr-2" />
                分享
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
