import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, leaderboardScores, InsertLeaderboardScore } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

/**
 * Save a quiz score to the leaderboard
 */
export async function saveQuizScore(score: InsertLeaderboardScore): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save quiz score: database not available");
    return;
  }

  try {
    await db.insert(leaderboardScores).values(score);
  } catch (error) {
    console.error("[Database] Failed to save quiz score:", error);
    throw error;
  }
}

/**
 * Get top scores from leaderboard
 */
export async function getTopScores(limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get top scores: database not available");
    return [];
  }

  try {
    const results = await db
      .select({
        id: leaderboardScores.id,
        userId: leaderboardScores.userId,
        userName: users.name,
        score: leaderboardScores.score,
        totalPhotos: leaderboardScores.totalPhotos,
        accuracy: leaderboardScores.accuracy,
        createdAt: leaderboardScores.createdAt,
      })
      .from(leaderboardScores)
      .innerJoin(users, eq(leaderboardScores.userId, users.id))
      .orderBy(desc(leaderboardScores.accuracy), desc(leaderboardScores.score))
      .limit(limit);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get top scores:", error);
    return [];
  }
}

/**
 * Get user scores
 */
export async function getUserScores(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user scores: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(leaderboardScores)
      .where(eq(leaderboardScores.userId, userId))
      .orderBy(desc(leaderboardScores.createdAt));

    return results;
  } catch (error) {
    console.error("[Database] Failed to get user scores:", error);
    return [];
  }
}

/**
 * Get user best score
 */
export async function getUserBestScore(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user best score: database not available");
    return undefined;
  }

  try {
    const results = await db
      .select()
      .from(leaderboardScores)
      .where(eq(leaderboardScores.userId, userId))
      .orderBy(desc(leaderboardScores.accuracy), desc(leaderboardScores.score))
      .limit(1);

    return results.length > 0 ? results[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get user best score:", error);
    return undefined;
  }
}


/**
 * Daily Challenge Functions
 */

import { dailyChallenges, dailyChallengeScores, userDailyChallengeProgress, InsertDailyChallengeScore, InsertUserDailyChallengeProgress } from '../drizzle/schema';

/**
 * Get today's daily challenge
 */
export async function getTodaysDailyChallenge() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get daily challenge: database not available");
    return undefined;
  }

  try {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    const result = await db
      .select()
      .from(dailyChallenges)
      .where(eq(dailyChallenges.date, today))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get today's daily challenge:", error);
    return undefined;
  }
}

/**
 * Get daily challenge by ID
 */
export async function getDailyChallengeById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get daily challenge: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(dailyChallenges)
      .where(eq(dailyChallenges.id, id))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get daily challenge:", error);
    return undefined;
  }
}

/**
 * Create or update today's daily challenge
 */
export async function createOrUpdateDailyChallenge(data: {
  theme: string;
  description?: string;
  photoIds: string[];
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create daily challenge: database not available");
    return undefined;
  }

  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Check if today's challenge already exists
    const existing = await db
      .select()
      .from(dailyChallenges)
      .where(eq(dailyChallenges.date, today))
      .limit(1);

    if (existing.length > 0) {
      // Update existing
      await db
        .update(dailyChallenges)
        .set({
          theme: data.theme,
          description: data.description,
          photoIds: JSON.stringify(data.photoIds),
        })
        .where(eq(dailyChallenges.date, today));
      return existing[0];
    } else {
      // Create new
      await db.insert(dailyChallenges).values({
        date: today,
        theme: data.theme,
        description: data.description,
        photoIds: JSON.stringify(data.photoIds),
        isActive: 1,
      });
      
      const result = await db
        .select()
        .from(dailyChallenges)
        .where(eq(dailyChallenges.date, today))
        .limit(1);
      
      return result.length > 0 ? result[0] : undefined;
    }
  } catch (error) {
    console.error("[Database] Failed to create/update daily challenge:", error);
    return undefined;
  }
}

/**
 * Save a daily challenge score
 */
export async function saveDailyChallengeScore(score: InsertDailyChallengeScore): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save daily challenge score: database not available");
    return;
  }

  try {
    await db.insert(dailyChallengeScores).values(score);
  } catch (error) {
    console.error("[Database] Failed to save daily challenge score:", error);
    throw error;
  }
}

/**
 * Get top scores for a daily challenge
 */
export async function getDailyChallengeTopScores(dailyChallengeId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get daily challenge top scores: database not available");
    return [];
  }

  try {
    const results = await db
      .select({
        id: dailyChallengeScores.id,
        userId: dailyChallengeScores.userId,
        userName: users.name,
        score: dailyChallengeScores.score,
        totalPhotos: dailyChallengeScores.totalPhotos,
        accuracy: dailyChallengeScores.accuracy,
        completedAt: dailyChallengeScores.completedAt,
      })
      .from(dailyChallengeScores)
      .innerJoin(users, eq(dailyChallengeScores.userId, users.id))
      .where(eq(dailyChallengeScores.dailyChallengeId, dailyChallengeId))
      .orderBy(desc(dailyChallengeScores.accuracy), desc(dailyChallengeScores.score))
      .limit(limit);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get daily challenge top scores:", error);
    return [];
  }
}

/**
 * Get user's daily challenge score
 */
export async function getUserDailyChallengeScore(userId: number, dailyChallengeId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user daily challenge score: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(dailyChallengeScores)
      .where(
        eq(dailyChallengeScores.userId, userId) &&
        eq(dailyChallengeScores.dailyChallengeId, dailyChallengeId)
      )
      .orderBy(desc(dailyChallengeScores.completedAt))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get user daily challenge score:", error);
    return undefined;
  }
}

/**
 * Update or create user daily challenge progress
 */
export async function updateUserDailyChallengeProgress(data: InsertUserDailyChallengeProgress): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update user daily challenge progress: database not available");
    return;
  }

  try {
    // Check if progress already exists
    const existing = await db
      .select()
      .from(userDailyChallengeProgress)
      .where(
        eq(userDailyChallengeProgress.userId, data.userId!) &&
        eq(userDailyChallengeProgress.dailyChallengeId, data.dailyChallengeId!)
      )
      .limit(1);

    if (existing.length > 0) {
      // Update existing
      await db
        .update(userDailyChallengeProgress)
        .set({
          participated: data.participated,
          bestScore: data.bestScore,
          bestAccuracy: data.bestAccuracy,
        })
        .where(
          eq(userDailyChallengeProgress.userId, data.userId!) &&
          eq(userDailyChallengeProgress.dailyChallengeId, data.dailyChallengeId!)
        );
    } else {
      // Create new
      await db.insert(userDailyChallengeProgress).values(data);
    }
  } catch (error) {
    console.error("[Database] Failed to update user daily challenge progress:", error);
    throw error;
  }
}

/**
 * Get user's daily challenge history
 */
export async function getUserDailyChallengeHistory(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user daily challenge history: database not available");
    return [];
  }

  try {
    const results = await db
      .select({
        id: userDailyChallengeProgress.id,
        dailyChallengeId: userDailyChallengeProgress.dailyChallengeId,
        theme: dailyChallenges.theme,
        date: dailyChallenges.date,
        participated: userDailyChallengeProgress.participated,
        bestScore: userDailyChallengeProgress.bestScore,
        bestAccuracy: userDailyChallengeProgress.bestAccuracy,
        participatedAt: userDailyChallengeProgress.participatedAt,
      })
      .from(userDailyChallengeProgress)
      .innerJoin(dailyChallenges, eq(userDailyChallengeProgress.dailyChallengeId, dailyChallenges.id))
      .where(eq(userDailyChallengeProgress.userId, userId))
      .orderBy(desc(dailyChallenges.date));

    return results;
  } catch (error) {
    console.error("[Database] Failed to get user daily challenge history:", error);
    return [];
  }
}
