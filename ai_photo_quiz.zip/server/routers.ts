import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { saveQuizScore, getTopScores, getUserScores, getUserBestScore, getTodaysDailyChallenge, getDailyChallengeById, saveDailyChallengeScore, getDailyChallengeTopScores, getUserDailyChallengeScore, updateUserDailyChallengeProgress, getUserDailyChallengeHistory } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  leaderboard: router({
    saveScore: protectedProcedure
      .input(z.object({
        score: z.number().min(0),
        totalPhotos: z.number().min(1),
        accuracy: z.number().min(0).max(100),
        answers: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        await saveQuizScore({
          userId: ctx.user.id,
          score: input.score,
          totalPhotos: input.totalPhotos,
          accuracy: input.accuracy,
          answers: input.answers,
        });
        return { success: true };
      }),

    getTopScores: publicProcedure
      .input(z.object({ limit: z.number().min(1).max(100).default(10) }).optional())
      .query(async ({ input }) => {
        const limit = input?.limit ?? 10;
        const scores = await getTopScores(limit);
        return scores.map((score, index) => ({
          ...score,
          rank: index + 1,
        }));
      }),

    getUserScores: protectedProcedure
      .query(async ({ ctx }) => {
        return await getUserScores(ctx.user.id);
      }),

    getUserBestScore: protectedProcedure
      .query(async ({ ctx }) => {
        return await getUserBestScore(ctx.user.id);
      }),
  }),

  dailyChallenge: router({
    getTodaysChallenge: publicProcedure
      .query(async () => {
        const challenge = await getTodaysDailyChallenge();
        if (challenge) {
          return {
            ...challenge,
            photoIds: JSON.parse(challenge.photoIds),
          };
        }
        return null;
      }),

    getChallengeById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const challenge = await getDailyChallengeById(input.id);
        if (challenge) {
          return {
            ...challenge,
            photoIds: JSON.parse(challenge.photoIds),
          };
        }
        return null;
      }),

    saveScore: protectedProcedure
      .input(z.object({
        dailyChallengeId: z.number(),
        score: z.number().min(0),
        totalPhotos: z.number().min(1),
        accuracy: z.number().min(0).max(100),
        answers: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        await saveDailyChallengeScore({
          userId: ctx.user.id,
          dailyChallengeId: input.dailyChallengeId,
          score: input.score,
          totalPhotos: input.totalPhotos,
          accuracy: input.accuracy,
          answers: input.answers,
        });

        // Update user progress
        await updateUserDailyChallengeProgress({
          userId: ctx.user.id,
          dailyChallengeId: input.dailyChallengeId,
          participated: 1,
          bestScore: input.score,
          bestAccuracy: input.accuracy,
        });

        return { success: true };
      }),

    getTopScores: publicProcedure
      .input(z.object({ dailyChallengeId: z.number(), limit: z.number().min(1).max(100).default(10) }))
      .query(async ({ input }) => {
        const scores = await getDailyChallengeTopScores(input.dailyChallengeId, input.limit);
        return scores.map((score, index) => ({
          ...score,
          rank: index + 1,
        }));
      }),

    getUserScore: protectedProcedure
      .input(z.object({ dailyChallengeId: z.number() }))
      .query(async ({ ctx, input }) => {
        return await getUserDailyChallengeScore(ctx.user.id, input.dailyChallengeId);
      }),

    getUserHistory: protectedProcedure
      .query(async ({ ctx }) => {
        return await getUserDailyChallengeHistory(ctx.user.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
