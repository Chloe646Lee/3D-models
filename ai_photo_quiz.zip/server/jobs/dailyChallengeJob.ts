/**
 * Daily Challenge Job
 * Scheduled job to reset daily challenges at midnight
 * 
 * This job runs once per day to:
 * 1. Deactivate yesterday's challenge
 * 2. Create today's challenge
 * 3. Ensure challenges are available for the next 7 days
 */

import { resetDailyChallenge, deactivatePreviousChallenge, initializeDailyChallengesForWeek, getTodayDateString } from '../services/dailyChallengeService';
import { notifyNewDailyChallenge } from '../services/notificationService';
import { rotatePhotosForChallenge, getTodaysChallengeWithPhotos } from '../services/photoLibraryService';
import { getDb } from '../db';
import { dailyChallenges } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

/**
 * Main job handler
 * Called once per day at midnight (00:00 UTC)
 */
export async function runDailyChallengeJob(): Promise<void> {
  console.log('[DailyChallengeJob] Starting daily challenge reset job...');
  
  try {
    // Step 1: Deactivate previous challenge
    await deactivatePreviousChallenge();
    
    // Step 2: Create today's challenge
    await resetDailyChallenge();
    
    // Step 3: Ensure next 7 days are prepared
    await initializeDailyChallengesForWeek();
    
    // Step 4: Update photos for today's challenge with 10 images
    const todayChallenge = await getTodaysChallengeWithPhotos();
    if (todayChallenge) {
      await rotatePhotosForChallenge(todayChallenge.id, 10);
      console.log(`[DailyChallengeJob] Updated photos for challenge ${todayChallenge.id} with 10 images`);
    }
    
    // Step 5: Send notifications about today's challenge
    await sendTodaysChallengeNotification();
    
    console.log('[DailyChallengeJob] ✅ Daily challenge job completed successfully with 10 photos per challenge');
  } catch (error) {
    console.error('[DailyChallengeJob] ❌ Error running daily challenge job:', error);
    throw error;
  }
}

/**
 * Send notifications about today's challenge
 */
async function sendTodaysChallengeNotification(): Promise<void> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn('[DailyChallengeJob] Database not available for sending notifications');
      return;
    }

    const todayDate = getTodayDateString();
    
    // Fetch today's challenge
    const todaysChallenge = await db
      .select()
      .from(dailyChallenges)
      .where(eq(dailyChallenges.date, todayDate))
      .limit(1);

    if (todaysChallenge.length === 0) {
      console.warn(`[DailyChallengeJob] No challenge found for ${todayDate}`);
      return;
    }

    const challenge = todaysChallenge[0];
    
    // Send notification
    await notifyNewDailyChallenge(challenge, {
      sendToOwner: true,
      sendToUsers: true,
    });

    console.log(`[DailyChallengeJob] ✅ Notifications sent for ${todayDate}`);
  } catch (error) {
    console.error('[DailyChallengeJob] Error sending notifications:', error);
    // Don't throw - notifications are non-critical
  }
}

/**
 * Calculate milliseconds until next midnight (UTC)
 */
export function getMillisecondsUntilNextMidnight(): number {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
  tomorrow.setUTCHours(0, 0, 0, 0);
  
  return tomorrow.getTime() - now.getTime();
}

/**
 * Schedule the daily challenge job
 * Runs once per day at midnight UTC
 */
export function scheduleDailyChallengeJob(): NodeJS.Timeout {
  console.log('[DailyChallengeJob] Scheduling daily challenge job...');
  
  // Run immediately on startup
  runDailyChallengeJob().catch(error => {
    console.error('[DailyChallengeJob] Error on startup:', error);
  });
  
  // Schedule for next midnight
  const scheduleNext = () => {
    const msUntilMidnight = getMillisecondsUntilNextMidnight();
    console.log(`[DailyChallengeJob] Next run in ${Math.round(msUntilMidnight / 1000 / 60)} minutes`);
    
    return setTimeout(() => {
      runDailyChallengeJob().catch(error => {
        console.error('[DailyChallengeJob] Error running scheduled job:', error);
      });
      scheduleNext(); // Reschedule for next day
    }, msUntilMidnight);
  };
  
  return scheduleNext();
}

/**
 * Alternative: Use cron-based scheduling (requires 'node-cron' package)
 * Uncomment to use instead of setTimeout-based scheduling
 */
/*
import cron from 'node-cron';

export function scheduleDailyChallengeJobWithCron(): cron.ScheduledTask {
  // Run at 00:00 UTC every day
  return cron.schedule('0 0 * * *', () => {
    console.log('[DailyChallengeJob] Running scheduled job at midnight UTC');
    runDailyChallengeJob().catch(error => {
      console.error('[DailyChallengeJob] Error running cron job:', error);
    });
  });
}
*/
