#!/usr/bin/env node

/**
 * Initialize Daily Challenges Script
 * 
 * This script initializes daily challenges for the next 7 days
 * Run once during deployment or setup
 * 
 * Usage: node init-daily-challenges.mjs
 */

import { drizzle } from 'drizzle-orm/mysql2';
import { eq } from 'drizzle-orm';
import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL environment variable not set');
  process.exit(1);
}

// Daily challenge themes
const dailyChallengeThemes = [
  {
    theme: '🏔️ 山景挑战',
    description: '今天的主题是壮丽的山景摄影。你能区分出 AI 生成的山景和真实摄影吗？',
    photoIds: ['photo-1', 'photo-6'],
  },
  {
    theme: '👤 人物肖像挑战',
    description: '今天的主题是人物肖像。看看你能否识别出 AI 生成的人物！',
    photoIds: ['photo-2', 'photo-7'],
  },
  {
    theme: '🌿 自然生物挑战',
    description: '今天的主题是自然生物。挑战你的眼力！',
    photoIds: ['photo-3', 'photo-8'],
  },
  {
    theme: '🏙️ 城市建筑挑战',
    description: '今天的主题是城市建筑。看看你能否识别出 AI 生成的建筑！',
    photoIds: ['photo-4', 'photo-9'],
  },
  {
    theme: '🍽️ 美食摄影挑战',
    description: '今天的主题是美食摄影。你能分辨出 AI 生成的美食吗？',
    photoIds: ['photo-5', 'photo-10'],
  },
];

function getTodayDateString() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getThemeForDate(dateString) {
  const [year, month, day] = dateString.split('-').map(Number);
  const dateNumber = year * 10000 + month * 100 + day;
  const themeIndex = dateNumber % dailyChallengeThemes.length;
  return dailyChallengeThemes[themeIndex];
}

async function initializeDailyChallenges() {
  let connection;
  
  try {
    console.log('🚀 Initializing daily challenges...');
    
    // Create connection
    connection = await mysql.createConnection(DATABASE_URL);
    
    const today = new Date();
    let successCount = 0;
    let skipCount = 0;
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);
      const dateString = date.toISOString().split('T')[0];
      
      // Check if challenge already exists
      const [existing] = await connection.execute(
        'SELECT id FROM daily_challenges WHERE date = ?',
        [dateString]
      );
      
      if (existing.length > 0) {
        console.log(`⏭️  Challenge for ${dateString} already exists`);
        skipCount++;
        continue;
      }
      
      // Get theme for this date
      const theme = getThemeForDate(dateString);
      
      // Insert new challenge
      await connection.execute(
        'INSERT INTO daily_challenges (date, theme, description, photoIds, isActive) VALUES (?, ?, ?, ?, ?)',
        [
          dateString,
          theme.theme,
          theme.description,
          JSON.stringify(theme.photoIds),
          i === 0 ? 1 : 0, // Only today's is active
        ]
      );
      
      console.log(`✅ Created challenge for ${dateString}: ${theme.theme}`);
      successCount++;
    }
    
    console.log(`\n📊 Summary:`);
    console.log(`   ✅ Created: ${successCount}`);
    console.log(`   ⏭️  Skipped: ${skipCount}`);
    console.log(`\n✨ Daily challenges initialized successfully!`);
    
  } catch (error) {
    console.error('❌ Error initializing daily challenges:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

// Run the initialization
initializeDailyChallenges();
