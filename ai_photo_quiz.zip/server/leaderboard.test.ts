import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("leaderboard", () => {
  describe("saveScore", () => {
    it("should save a quiz score for authenticated user", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.leaderboard.saveScore({
        score: 8,
        totalPhotos: 10,
        accuracy: 80,
        answers: JSON.stringify([
          { photoId: "1", userAnswer: "ai", isCorrect: true },
          { photoId: "2", userAnswer: "real", isCorrect: false },
        ]),
      });

      expect(result).toEqual({ success: true });
    });

    it("should validate score input", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.leaderboard.saveScore({
          score: -1, // Invalid: negative score
          totalPhotos: 10,
          accuracy: 80,
          answers: "[]",
        });
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should validate accuracy range", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.leaderboard.saveScore({
          score: 8,
          totalPhotos: 10,
          accuracy: 150, // Invalid: accuracy > 100
          answers: "[]",
        });
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getTopScores", () => {
    it("should return top scores as public data", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.leaderboard.getTopScores({
        limit: 10,
      });

      expect(Array.isArray(result)).toBe(true);
      // Each result should have rank field
      if (result.length > 0) {
        expect(result[0]).toHaveProperty("rank");
        expect(result[0].rank).toBe(1);
      }
    });

    it("should respect limit parameter", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.leaderboard.getTopScores({
        limit: 5,
      });

      expect(result.length).toBeLessThanOrEqual(5);
    });

    it("should validate limit bounds", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      try {
        await caller.leaderboard.getTopScores({
          limit: 101, // Invalid: limit > 100
        });
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getUserScores", () => {
    it("should require authentication", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      try {
        await caller.leaderboard.getUserScores();
        expect.fail("Should have thrown authentication error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should return user's scores when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.leaderboard.getUserScores();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("getUserBestScore", () => {
    it("should require authentication", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      try {
        await caller.leaderboard.getUserBestScore();
        expect.fail("Should have thrown authentication error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should return user's best score when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.leaderboard.getUserBestScore();

      // Result can be undefined if user has no scores yet
      if (result) {
        expect(result).toHaveProperty("score");
        expect(result).toHaveProperty("accuracy");
        expect(result).toHaveProperty("totalPhotos");
      }
    });
  });
});
