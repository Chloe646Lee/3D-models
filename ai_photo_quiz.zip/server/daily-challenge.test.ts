import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("dailyChallenge", () => {
  describe("getTodaysChallenge", () => {
    it("should return today's challenge as public data", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.dailyChallenge.getTodaysChallenge();

      // Result can be null if no challenge is set up for today
      if (result) {
        expect(result).toHaveProperty("id");
        expect(result).toHaveProperty("theme");
        expect(result).toHaveProperty("photoIds");
        expect(Array.isArray(result.photoIds)).toBe(true);
      }
    });
  });

  describe("getChallengeById", () => {
    it("should return challenge by ID as public data", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      // Try with a test ID (will return null if not found)
      const result = await caller.dailyChallenge.getChallengeById({ id: 1 });

      // Result can be null if challenge doesn't exist
      if (result) {
        expect(result).toHaveProperty("id");
        expect(result).toHaveProperty("theme");
        expect(result).toHaveProperty("photoIds");
      }
    });
  });

  describe("saveScore", () => {
    it("should save a daily challenge score for authenticated user", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.dailyChallenge.saveScore({
        dailyChallengeId: 1,
        score: 7,
        totalPhotos: 10,
        accuracy: 70,
        answers: JSON.stringify([
          { photoId: "1", userAnswer: "ai", isCorrect: true },
          { photoId: "2", userAnswer: "real", isCorrect: false },
        ]),
      });

      expect(result).toEqual({ success: true });
    });

    it("should validate score input", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.dailyChallenge.saveScore({
          dailyChallengeId: 1,
          score: -1, // Invalid: negative score
          totalPhotos: 10,
          accuracy: 70,
          answers: "[]",
        });
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should validate accuracy range", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.dailyChallenge.saveScore({
          dailyChallengeId: 1,
          score: 7,
          totalPhotos: 10,
          accuracy: 150, // Invalid: accuracy > 100
          answers: "[]",
        });
        expect.fail("Should have thrown validation error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getTopScores", () => {
    it("should return top scores for a daily challenge", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.dailyChallenge.getTopScores({
        dailyChallengeId: 1,
        limit: 10,
      });

      expect(Array.isArray(result)).toBe(true);
      // Each result should have rank field
      if (result.length > 0) {
        expect(result[0]).toHaveProperty("rank");
        expect(result[0].rank).toBe(1);
      }
    });

    it("should respect limit parameter", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.dailyChallenge.getTopScores({
        dailyChallengeId: 1,
        limit: 5,
      });

      expect(result.length).toBeLessThanOrEqual(5);
    });
  });

  describe("getUserScore", () => {
    it("should require authentication", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      try {
        await caller.dailyChallenge.getUserScore({ dailyChallengeId: 1 });
        expect.fail("Should have thrown authentication error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should return user's score for a challenge when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.dailyChallenge.getUserScore({ dailyChallengeId: 1 });

      // Result can be undefined if user hasn't participated
      if (result) {
        expect(result).toHaveProperty("score");
        expect(result).toHaveProperty("accuracy");
      }
    });
  });

  describe("getUserHistory", () => {
    it("should require authentication", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      try {
        await caller.dailyChallenge.getUserHistory();
        expect.fail("Should have thrown authentication error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should return user's daily challenge history when authenticated", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.dailyChallenge.getUserHistory();

      expect(Array.isArray(result)).toBe(true);
    });
  });
});
