/**
 * Initialize Daily Challenge
 * This script creates today's daily challenge with a predefined set of photos
 * Run: node init-daily-challenge.mjs
 */

import { drizzle } from 'drizzle-orm/mysql2';
import * as schema from '../drizzle/schema.ts';
import { eq } from 'drizzle-orm';

const db = drizzle(process.env.DATABASE_URL);

// Define daily challenge themes and photo selections
const dailyChallengeThemes = [
  {
    date: new Date().toISOString().split('T')[0],
    theme: '风景摄影挑战',
    description: '今天的主题是风景摄影。你能区分出 AI 生成的风景和真实摄影吗？',
    photoIds: ['photo-1', 'photo-6'], // Mix of AI and real landscape photos
  },
  {
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    theme: '自然生物挑战',
    description: '今天的主题是自然生物。挑战你的眼力！',
    photoIds: ['photo-3', 'photo-8'],
  },
  {
    date: new Date(Date.now() + 172800000).toISOString().split('T')[0], // Day after tomorrow
    theme: '城市建筑挑战',
    description: '今天的主题是城市建筑。看看你能否识别出 AI 生成的建筑！',
    photoIds: ['photo-4', 'photo-9'],
  },
];

async function initializeDailyChallenge() {
  try {
    console.log('🚀 Initializing daily challenges...');

    for (const challenge of dailyChallengeThemes) {
      // Check if challenge already exists
      const existing = await db
        .select()
        .from(schema.dailyChallenges)
        .where(eq(schema.dailyChallenges.date, challenge.date))
        .limit(1);

      if (existing.length > 0) {
        console.log(`✓ Challenge for ${challenge.date} already exists`);
      } else {
        // Create new challenge
        await db.insert(schema.dailyChallenges).values({
          date: challenge.date,
          theme: challenge.theme,
          description: challenge.description,
          photoIds: JSON.stringify(challenge.photoIds),
          isActive: 1,
        });
        console.log(`✓ Created challenge for ${challenge.date}: ${challenge.theme}`);
      }
    }

    console.log('✅ Daily challenges initialized successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error initializing daily challenges:', error);
    process.exit(1);
  }
}

initializeDailyChallenge();
