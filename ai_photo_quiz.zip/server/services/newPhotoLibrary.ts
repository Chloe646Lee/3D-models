/**
 * New Photo Library - Imported from Unsplash
 * High-quality photography for AI vs Real Photo Quiz
 */

export const NEW_PHOTO_LIBRARY = [
  // ============ 风景类 (Landscape) ============
  // AI Generated Landscapes
  { id: 'ai_landscape_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_1-LqQ2zpDQrC4SnTPyyfArVY.png', isAI: true, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'ai_landscape_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_2-dULoKAuMpP5Fq8ut9jwk6G.webp', isAI: true, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'ai_landscape_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_3-ZcGXVfM3TxReuicBJMD4Lc.webp', isAI: true, category: '🏔️ 风景', theme: 'landscape' },
  
  // Real Landscapes from Unsplash
  { id: 'real_landscape_1', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_2', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_3', url: 'https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_4', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_5', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_6', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_7', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },
  { id: 'real_landscape_8', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80', isAI: false, category: '🏔️ 风景', theme: 'landscape' },

  // ============ 人物类 (Portrait) ============
  // AI Generated Portraits
  { id: 'ai_portrait_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_1-Ypo4sMkLDeDs26scNRvNCn.png', isAI: true, category: '👤 人物', theme: 'portrait' },
  { id: 'ai_portrait_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_2-hoejJWj4JEcLokijipcdqi.webp', isAI: true, category: '👤 人物', theme: 'portrait' },
  { id: 'ai_portrait_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_3-4VVMkU6RsV59iDY3zowz8A.png', isAI: true, category: '👤 人物', theme: 'portrait' },
  
  // Real Portraits from Unsplash
  { id: 'real_portrait_1', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_2', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_3', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_4', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_5', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_6', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_7', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },
  { id: 'real_portrait_8', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80', isAI: false, category: '👤 人物', theme: 'portrait' },

  // ============ 自然类 (Nature) ============
  // AI Generated Nature
  { id: 'ai_nature_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_1-cyrtzib2YFRvEoeN4VHA3i.png', isAI: true, category: '🌿 自然', theme: 'nature' },
  { id: 'ai_nature_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_2-Y4bYnyUtV6HBfMbeyFmBwA.webp', isAI: true, category: '🌿 自然', theme: 'nature' },
  { id: 'ai_nature_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_3-A2ePwB5HaXBeSorxykWVap.webp', isAI: true, category: '🌿 自然', theme: 'nature' },
  
  // Real Nature from Unsplash
  { id: 'real_nature_1', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_2', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_3', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_4', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_5', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_6', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_7', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },
  { id: 'real_nature_8', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80', isAI: false, category: '🌿 自然', theme: 'nature' },

  // ============ 城市类 (Urban) ============
  // AI Generated Urban
  { id: 'ai_urban_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_1-RWMioSmD3zNzE9tH98dC7D.png', isAI: true, category: '🏙️ 城市', theme: 'urban' },
  { id: 'ai_urban_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_2-k9K9QGqQCZrAU4ZDybg4uM.webp', isAI: true, category: '🏙️ 城市', theme: 'urban' },
  { id: 'ai_urban_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_3-CdHuGSdrSJz33rf4WsRSZM.webp', isAI: true, category: '🏙️ 城市', theme: 'urban' },
  
  // Real Urban from Unsplash
  { id: 'real_urban_1', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_2', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_3', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_4', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_5', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_6', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_7', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },
  { id: 'real_urban_8', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800&q=80', isAI: false, category: '🏙️ 城市', theme: 'urban' },

  // ============ 美食类 (Food) ============
  // AI Generated Food
  { id: 'ai_food_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_1-LYsaLg6NZqgUsNjBfth7DQ.png', isAI: true, category: '🍽️ 美食', theme: 'food' },
  { id: 'ai_food_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_2-H4Spr3p55ftxab449Rbap5.webp', isAI: true, category: '🍽️ 美食', theme: 'food' },
  { id: 'ai_food_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_3-hkK3iSVUATgfLcK47zd3ai.png', isAI: true, category: '🍽️ 美食', theme: 'food' },
  
  // Real Food from Unsplash
  { id: 'real_food_1', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_2', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_3', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_4', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_5', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_6', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_7', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
  { id: 'real_food_8', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', isAI: false, category: '🍽️ 美食', theme: 'food' },
];

export type PhotoItem = typeof NEW_PHOTO_LIBRARY[number];

/**
 * Get a random subset of photos for a daily challenge
 * Ensures balanced mix of AI and real photos
 */
export function getRandomPhotosForChallenge(count: number = 10): PhotoItem[] {
  const shuffled = [...NEW_PHOTO_LIBRARY].sort(() => Math.random() - 0.5);
  
  // Ensure balanced mix: roughly 50% AI, 50% real
  const aiPhotos = shuffled.filter(p => p.isAI).slice(0, Math.ceil(count / 2));
  const realPhotos = shuffled.filter(p => !p.isAI).slice(0, Math.floor(count / 2));
  
  const selected = [...aiPhotos, ...realPhotos].sort(() => Math.random() - 0.5);
  return selected.slice(0, count);
}

/**
 * Get photos filtered by theme
 */
export function getPhotosByTheme(theme: string, count: number = 10): PhotoItem[] {
  const themePhotos = NEW_PHOTO_LIBRARY.filter(p => p.theme === theme);
  const shuffled = themePhotos.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

/**
 * Get all themes
 */
export function getAllThemes(): string[] {
  return ['landscape', 'portrait', 'nature', 'urban', 'food'];
}
