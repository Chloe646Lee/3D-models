/**
 * Photo Library Service
 * Manages the photo library with support for daily updates
 */

import { getDb } from '../db';
import { dailyChallenges } from '../../drizzle/schema';
import { eq, and } from 'drizzle-orm';

// Extended photo library with more images
export const EXTENDED_PHOTO_LIBRARY = [
  // Original photos (batch 1)
  { id: 'ai_landscape_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_1-LqQ2zpDQrC4SnTPyyfArVY.png', isAI: true, category: '🏔️ 风景' },
  { id: 'ai_portrait_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_1-Ypo4sMkLDeDs26scNRvNCn.png', isAI: true, category: '👤 人物' },
  { id: 'ai_nature_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_1-cyrtzib2YFRvEoeN4VHA3i.png', isAI: true, category: '🌿 自然' },
  { id: 'ai_urban_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_1-RWMioSmD3zNzE9tH98dC7D.png', isAI: true, category: '🏙️ 城市' },
  { id: 'ai_food_1', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_1-LYsaLg6NZqgUsNjBfth7DQ.png', isAI: true, category: '🍽️ 美食' },

  // Batch 2 - New AI images
  { id: 'ai_landscape_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_2-dULoKAuMpP5Fq8ut9jwk6G.webp', isAI: true, category: '🏔️ 风景' },
  { id: 'ai_portrait_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_2-hoejJWj4JEcLokijipcdqi.webp', isAI: true, category: '👤 人物' },
  { id: 'ai_nature_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_2-Y4bYnyUtV6HBfMbeyFmBwA.webp', isAI: true, category: '🌿 自然' },
  { id: 'ai_urban_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_2-k9K9QGqQCZrAU4ZDybg4uM.webp', isAI: true, category: '🏙️ 城市' },
  { id: 'ai_food_2', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_2-H4Spr3p55ftxab449Rbap5.webp', isAI: true, category: '🍽️ 美食' },

  // Batch 3 - More AI images
  { id: 'ai_landscape_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_landscape_3-ZcGXVfM3TxReuicBJMD4Lc.webp', isAI: true, category: '🏔️ 风景' },
  { id: 'ai_portrait_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_portrait_3-4VVMkU6RsV59iDY3zowz8A.png', isAI: true, category: '👤 人物' },
  { id: 'ai_nature_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_nature_3-A2ePwB5HaXBeSorxykWVap.webp', isAI: true, category: '🌿 自然' },
  { id: 'ai_urban_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_urban_3-CdHuGSdrSJz33rf4WsRSZM.webp', isAI: true, category: '🏙️ 城市' },
  { id: 'ai_food_3', url: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663380730894/2v9q4tz5M3FeV6RAxqbQsm/ai_food_3-hkK3iSVUATgfLcK47zd3ai.png', isAI: true, category: '🍽️ 美食' },

  // Real photography samples
  { id: 'real_landscape_1', url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800', isAI: false, category: '🏔️ 风景' },
  { id: 'real_portrait_1', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800', isAI: false, category: '👤 人物' },
  { id: 'real_nature_1', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800', isAI: false, category: '🌿 自然' },
  { id: 'real_urban_1', url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=800', isAI: false, category: '🏙️ 城市' },
  { id: 'real_food_1', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800', isAI: false, category: '🍽️ 美食' },
];

export type PhotoItem = typeof EXTENDED_PHOTO_LIBRARY[number];

/**
 * Get a random subset of photos for a daily challenge
 * Ensures balanced mix of AI and real photos
 */
export function getRandomPhotosForChallenge(count: number = 10): PhotoItem[] {
  const shuffled = [...EXTENDED_PHOTO_LIBRARY].sort(() => Math.random() - 0.5);
  
  // Ensure balanced mix: roughly 50% AI, 50% real
  const aiPhotos = shuffled.filter(p => p.isAI).slice(0, Math.ceil(count / 2));
  const realPhotos = shuffled.filter(p => !p.isAI).slice(0, Math.floor(count / 2));
  
  const selected = [...aiPhotos, ...realPhotos].sort(() => Math.random() - 0.5);
  return selected.slice(0, count);
}

/**
 * Update daily challenge with new photos
 */
export async function updateDailyChallengePhotos(challengeId: number, photos: PhotoItem[]): Promise<void> {
  const database = await getDb();
  if (!database) {
    throw new Error('Database not available');
  }

  // Store photo IDs as JSON in the photoIds field
  const photoIds = JSON.stringify(
    photos.map((p, idx) => ({
      id: p.id,
      url: p.url,
      isAI: p.isAI,
      category: p.category,
      order: idx,
    }))
  );

  // Update the challenge with new photos
  await database
    .update(dailyChallenges)
    .set({ photoIds })
    .where(eq(dailyChallenges.id, challengeId));
}

/**
 * Get today's challenge with photos
 */
export async function getTodaysChallengeWithPhotos() {
  const database = await getDb();
  if (!database) {
    throw new Error('Database not available');
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().split('T')[0];

  const challenges = await database.select().from(dailyChallenges).where(
    and(
      eq(dailyChallenges.date, todayStr),
      eq(dailyChallenges.isActive, 1)
    )
  );

  return challenges.length > 0 ? challenges[0] : null;
}

/**
 * Rotate photos for a challenge (update with new random selection)
 */
export async function rotatePhotosForChallenge(challengeId: number, photoCount: number = 10): Promise<void> {
  const newPhotos = getRandomPhotosForChallenge(photoCount);
  await updateDailyChallengePhotos(challengeId, newPhotos);
}
