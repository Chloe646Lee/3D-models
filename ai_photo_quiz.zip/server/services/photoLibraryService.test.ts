import { describe, it, expect, beforeEach } from 'vitest';
import {
  EXTENDED_PHOTO_LIBRARY,
  getRandomPhotosForChallenge,
  PhotoItem,
} from './photoLibraryService';

describe('Photo Library Service', () => {
  describe('EXTENDED_PHOTO_LIBRARY', () => {
    it('should have at least 20 photos', () => {
      expect(EXTENDED_PHOTO_LIBRARY.length).toBeGreaterThanOrEqual(20);
    });

    it('should have a mix of AI and real photos', () => {
      const aiPhotos = EXTENDED_PHOTO_LIBRARY.filter(p => p.isAI);
      const realPhotos = EXTENDED_PHOTO_LIBRARY.filter(p => !p.isAI);
      
      expect(aiPhotos.length).toBeGreaterThan(0);
      expect(realPhotos.length).toBeGreaterThan(0);
    });

    it('should have all required fields for each photo', () => {
      for (const photo of EXTENDED_PHOTO_LIBRARY) {
        expect(photo).toHaveProperty('id');
        expect(photo).toHaveProperty('url');
        expect(photo).toHaveProperty('isAI');
        expect(photo).toHaveProperty('category');
        
        expect(typeof photo.id).toBe('string');
        expect(typeof photo.url).toBe('string');
        expect(typeof photo.isAI).toBe('boolean');
        expect(typeof photo.category).toBe('string');
      }
    });

    it('should have valid URLs', () => {
      for (const photo of EXTENDED_PHOTO_LIBRARY) {
        expect(photo.url).toMatch(/^https?:\/\//);
      }
    });

    it('should have valid categories', () => {
      const validCategories = ['🏔️ 风景', '👤 人物', '🌿 自然', '🏙️ 城市', '🍽️ 美食'];
      for (const photo of EXTENDED_PHOTO_LIBRARY) {
        expect(validCategories).toContain(photo.category);
      }
    });
  });

  describe('getRandomPhotosForChallenge', () => {
    it('should return requested number of photos', () => {
      const photos = getRandomPhotosForChallenge(10);
      expect(photos.length).toBe(10);
    });

    it('should return default 10 photos when no count specified', () => {
      const photos = getRandomPhotosForChallenge();
      expect(photos.length).toBe(10);
    });

    it('should return balanced mix of AI and real photos', () => {
      const photos = getRandomPhotosForChallenge(10);
      const aiPhotos = photos.filter(p => p.isAI);
      const realPhotos = photos.filter(p => !p.isAI);
      
      // Should be roughly 50/50 split
      expect(aiPhotos.length).toBeGreaterThan(0);
      expect(realPhotos.length).toBeGreaterThan(0);
      expect(Math.abs(aiPhotos.length - realPhotos.length)).toBeLessThanOrEqual(2);
    });

    it('should return different photos on each call', () => {
      const photos1 = getRandomPhotosForChallenge(10);
      const photos2 = getRandomPhotosForChallenge(10);
      
      const ids1 = photos1.map(p => p.id).sort();
      const ids2 = photos2.map(p => p.id).sort();
      
      // Very unlikely to get exact same order twice
      expect(ids1.join(',')).not.toBe(ids2.join(','));
    });

    it('should not exceed available photos', () => {
      const photos = getRandomPhotosForChallenge(100);
      expect(photos.length).toBeLessThanOrEqual(EXTENDED_PHOTO_LIBRARY.length);
    });

    it('should return unique photos (no duplicates)', () => {
      const photos = getRandomPhotosForChallenge(10);
      const ids = photos.map(p => p.id);
      const uniqueIds = new Set(ids);
      
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('should handle small counts', () => {
      const photos = getRandomPhotosForChallenge(1);
      expect(photos.length).toBe(1);
    });

    it('should handle odd counts for balanced distribution', () => {
      const photos = getRandomPhotosForChallenge(5);
      expect(photos.length).toBe(5);
      
      const aiPhotos = photos.filter(p => p.isAI);
      const realPhotos = photos.filter(p => !p.isAI);
      
      // With 5 photos: 3 AI + 2 real or 2 AI + 3 real
      expect(Math.abs(aiPhotos.length - realPhotos.length)).toBeLessThanOrEqual(1);
    });
  });

  describe('Photo diversity', () => {
    it('should have photos from multiple categories', () => {
      const categories = new Set(EXTENDED_PHOTO_LIBRARY.map(p => p.category));
      expect(categories.size).toBeGreaterThanOrEqual(5);
    });

    it('should have multiple photos per category', () => {
      const categoryCount: Record<string, number> = {};
      
      for (const photo of EXTENDED_PHOTO_LIBRARY) {
        categoryCount[photo.category] = (categoryCount[photo.category] || 0) + 1;
      }
      
      for (const count of Object.values(categoryCount)) {
        expect(count).toBeGreaterThanOrEqual(2);
      }
    });

    it('should have AI photos from multiple sources', () => {
      const aiPhotos = EXTENDED_PHOTO_LIBRARY.filter(p => p.isAI);
      const aiUrls = aiPhotos.map(p => p.url);
      
      // Check for variety in URLs
      const uniqueUrls = new Set(aiUrls);
      expect(uniqueUrls.size).toBe(aiUrls.length);
    });
  });
});
