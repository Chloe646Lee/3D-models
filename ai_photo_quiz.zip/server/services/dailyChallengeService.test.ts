import { describe, expect, it, beforeEach } from "vitest";
import {
  getTodayDateString,
  getThemeForDate,
  dailyChallengeThemes,
} from "./dailyChallengeService";

describe("Daily Challenge Service", () => {
  describe("getTodayDateString", () => {
    it("should return today's date in YYYY-MM-DD format", () => {
      const result = getTodayDateString();
      
      // Verify format
      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      
      // Verify it's today's date
      const today = new Date();
      const expectedDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      expect(result).toBe(expectedDate);
    });
  });

  describe("getThemeForDate", () => {
    it("should return a valid theme for any date", () => {
      const testDates = [
        "2024-01-01",
        "2024-06-15",
        "2025-12-31",
        "2026-03-22",
      ];

      testDates.forEach(date => {
        const theme = getThemeForDate(date);
        expect(theme).toBeDefined();
        expect(theme).toHaveProperty("theme");
        expect(theme).toHaveProperty("description");
        expect(theme).toHaveProperty("photoIds");
        expect(Array.isArray(theme.photoIds)).toBe(true);
      });
    });

    it("should return consistent theme for the same date", () => {
      const date = "2024-03-15";
      const theme1 = getThemeForDate(date);
      const theme2 = getThemeForDate(date);
      
      expect(theme1).toEqual(theme2);
    });

    it("should cycle through all themes across dates", () => {
      const themes = new Set();
      
      // Check 30 consecutive dates
      for (let i = 0; i < 30; i++) {
        const date = new Date(2024, 0, 1 + i);
        const dateString = date.toISOString().split('T')[0];
        const theme = getThemeForDate(dateString);
        themes.add(theme.theme);
      }
      
      // Should have multiple different themes
      expect(themes.size).toBeGreaterThan(1);
      expect(themes.size).toBeLessThanOrEqual(dailyChallengeThemes.length);
    });

    it("should use modulo to cycle through themes", () => {
      // Test that themes repeat after the theme count
      const themeCount = dailyChallengeThemes.length;
      
      const date1 = "2024-01-01";
      const date2 = new Date(2024, 0, 1 + themeCount);
      const dateString2 = date2.toISOString().split('T')[0];
      
      const theme1 = getThemeForDate(date1);
      const theme2 = getThemeForDate(dateString2);
      
      // After themeCount days, should get the same theme
      expect(theme1.theme).toBe(theme2.theme);
    });

    it("should have valid photo IDs in each theme", () => {
      dailyChallengeThemes.forEach(theme => {
        expect(Array.isArray(theme.photoIds)).toBe(true);
        expect(theme.photoIds.length).toBeGreaterThan(0);
        theme.photoIds.forEach(id => {
          expect(typeof id).toBe("string");
          expect(id.length).toBeGreaterThan(0);
        });
      });
    });
  });

  describe("Daily Challenge Themes", () => {
    it("should have at least 5 themes", () => {
      expect(dailyChallengeThemes.length).toBeGreaterThanOrEqual(5);
    });

    it("each theme should have required properties", () => {
      dailyChallengeThemes.forEach(theme => {
        expect(theme).toHaveProperty("theme");
        expect(theme).toHaveProperty("description");
        expect(theme).toHaveProperty("photoIds");
        
        expect(typeof theme.theme).toBe("string");
        expect(typeof theme.description).toBe("string");
        expect(Array.isArray(theme.photoIds)).toBe(true);
      });
    });

    it("each theme should have non-empty strings", () => {
      dailyChallengeThemes.forEach(theme => {
        expect(theme.theme.length).toBeGreaterThan(0);
        expect(theme.description.length).toBeGreaterThan(0);
        expect(theme.photoIds.length).toBeGreaterThan(0);
      });
    });
  });
});
