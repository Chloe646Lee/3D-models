/**
 * Notification Service for Daily Challenges
 * Handles sending notifications to users when new challenges are published
 */

import { notifyOwner } from '../_core/notification';
import type { DailyChallenge } from '../../drizzle/schema';

export interface NotificationOptions {
  sendToOwner?: boolean;
  sendToUsers?: boolean;
}

/**
 * Send notification when a new daily challenge is published
 */
export async function notifyNewDailyChallenge(
  challenge: DailyChallenge,
  options: NotificationOptions = { sendToOwner: true, sendToUsers: true }
): Promise<void> {
  try {
    const title = `🎮 新的每日挑战发布！`;
    const content = `
📅 今日主题：${challenge.theme}

${challenge.description}

🏆 快来参加挑战，与其他玩家竞争排名吧！

⏰ 挑战将在明天午夜重置，现在就开始吧！
    `.trim();

    // Notify project owner
    if (options.sendToOwner) {
      const ownerNotified = await notifyOwner({
        title: `[AI Photo Quiz] ${title}`,
        content: `
新的每日挑战已发布：

主题：${challenge.theme}
描述：${challenge.description}
日期：${challenge.date}
图片数量：${challenge.photoIds ? JSON.parse(challenge.photoIds).length : 0}
        `.trim(),
      });

      if (ownerNotified) {
        console.log(`[NotificationService] ✅ Owner notification sent for ${challenge.date}`);
      } else {
        console.warn(`[NotificationService] ⚠️ Failed to send owner notification for ${challenge.date}`);
      }
    }

    // TODO: Implement user notifications
    // This would require:
    // 1. A user_notifications table to store notification preferences
    // 2. A way to send notifications to individual users (push notifications, email, in-app)
    // 3. User notification subscription management
    if (options.sendToUsers) {
      console.log(`[NotificationService] 📢 User notifications for ${challenge.date} - TODO: Implement`);
    }
  } catch (error) {
    console.error('[NotificationService] Error sending notifications:', error);
    throw error;
  }
}

/**
 * Send notification about challenge statistics
 */
export async function notifyChallengeSummary(
  date: string,
  stats: {
    totalParticipants: number;
    averageScore: number;
    averageAccuracy: number;
    topScore: number;
  }
): Promise<void> {
  try {
    const title = `📊 ${date} 挑战总结`;
    const content = `
参与人数：${stats.totalParticipants}
平均得分：${stats.averageScore.toFixed(2)}
平均准确率：${stats.averageAccuracy.toFixed(1)}%
最高得分：${stats.topScore}

感谢所有参与者的热情参与！
    `.trim();

    const notified = await notifyOwner({
      title,
      content,
    });

    if (notified) {
      console.log(`[NotificationService] ✅ Challenge summary notification sent for ${date}`);
    }
  } catch (error) {
    console.error('[NotificationService] Error sending summary notification:', error);
  }
}

/**
 * Send notification about user achievements
 */
export async function notifyUserAchievement(
  userName: string,
  achievement: string,
  details: string
): Promise<void> {
  try {
    const title = `🏆 用户成就：${achievement}`;
    const content = `
用户：${userName}
成就：${achievement}
详情：${details}
    `.trim();

    const notified = await notifyOwner({
      title,
      content,
    });

    if (notified) {
      console.log(`[NotificationService] ✅ Achievement notification sent for ${userName}`);
    }
  } catch (error) {
    console.error('[NotificationService] Error sending achievement notification:', error);
  }
}

/**
 * Format challenge notification message
 */
export function formatChallengeNotification(challenge: DailyChallenge): {
  title: string;
  content: string;
} {
  const photoCount = challenge.photoIds ? JSON.parse(challenge.photoIds).length : 0;

  return {
    title: `🎮 新的每日挑战：${challenge.theme}`,
    content: `
${challenge.description}

📸 图片数量：${photoCount}
📅 挑战日期：${challenge.date}

快来参加挑战，看看你能得多少分！
    `.trim(),
  };
}
