/**
 * Daily Challenge Service
 * Handles daily challenge creation, rotation, and reset logic
 */

import { getDb } from '../db';
import { dailyChallenges, type InsertDailyChallenge } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

/**
 * Photo pool for daily challenges
 * Each theme has a set of photo IDs that can be rotated
 */
export const dailyChallengeThemes = [
  {
    theme: '🏔️ 山景挑战',
    description: '今天的主题是壮丽的山景摄影。你能区分出 AI 生成的山景和真实摄影吗？',
    photoIds: ['photo-1', 'photo-6'],
  },
  {
    theme: '👤 人物肖像挑战',
    description: '今天的主题是人物肖像。看看你能否识别出 AI 生成的人物！',
    photoIds: ['photo-2', 'photo-7'],
  },
  {
    theme: '🌿 自然生物挑战',
    description: '今天的主题是自然生物。挑战你的眼力！',
    photoIds: ['photo-3', 'photo-8'],
  },
  {
    theme: '🏙️ 城市建筑挑战',
    description: '今天的主题是城市建筑。看看你能否识别出 AI 生成的建筑！',
    photoIds: ['photo-4', 'photo-9'],
  },
  {
    theme: '🍽️ 美食摄影挑战',
    description: '今天的主题是美食摄影。你能分辨出 AI 生成的美食吗？',
    photoIds: ['photo-5', 'photo-10'],
  },
];

/**
 * Get today's date in YYYY-MM-DD format
 */
export function getTodayDateString(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Get a theme for a specific date
 * Uses date-based rotation to ensure consistency
 */
export function getThemeForDate(dateString: string): (typeof dailyChallengeThemes)[0] {
  // Convert date string to a number for consistent rotation
  const [year, month, day] = dateString.split('-').map(Number);
  const dateNumber = year * 10000 + month * 100 + day;
  
  // Use modulo to cycle through themes
  const themeIndex = dateNumber % dailyChallengeThemes.length;
  return dailyChallengeThemes[themeIndex];
}

/**
 * Create or update today's daily challenge
 * Should be called once per day (via scheduled job)
 */
export async function resetDailyChallenge(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.error('[DailyChallenge] Database not available');
    return;
  }

  const todayDate = getTodayDateString();
  const theme = getThemeForDate(todayDate);

  try {
    // Check if today's challenge already exists
    const existing = await db
      .select()
      .from(dailyChallenges)
      .where(eq(dailyChallenges.date, todayDate))
      .limit(1);

    if (existing.length > 0) {
      console.log(`[DailyChallenge] Challenge for ${todayDate} already exists`);
      return;
    }

    // Create new daily challenge
    const newChallenge: InsertDailyChallenge = {
      date: todayDate,
      theme: theme.theme,
      description: theme.description,
      photoIds: JSON.stringify(theme.photoIds),
      isActive: 1,
    };

    await db.insert(dailyChallenges).values(newChallenge);
    console.log(`[DailyChallenge] ✅ Created challenge for ${todayDate}: ${theme.theme}`);
  } catch (error) {
    console.error('[DailyChallenge] Error creating daily challenge:', error);
    throw error;
  }
}

/**
 * Deactivate yesterday's challenge
 */
export async function deactivatePreviousChallenge(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.error('[DailyChallenge] Database not available');
    return;
  }

  try {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayDate = yesterday.toISOString().split('T')[0];

    // Deactivate yesterday's challenge
    await db
      .update(dailyChallenges)
      .set({ isActive: 0 })
      .where(eq(dailyChallenges.date, yesterdayDate));

    console.log(`[DailyChallenge] ✅ Deactivated challenge for ${yesterdayDate}`);
  } catch (error) {
    console.error('[DailyChallenge] Error deactivating previous challenge:', error);
    throw error;
  }
}

/**
 * Initialize daily challenges for the next 7 days
 * Useful for initial setup or batch creation
 */
export async function initializeDailyChallengesForWeek(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.error('[DailyChallenge] Database not available');
    return;
  }

  try {
    const today = new Date();
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);
      const dateString = date.toISOString().split('T')[0];
      
      // Check if challenge already exists
      const existing = await db
        .select()
        .from(dailyChallenges)
        .where(eq(dailyChallenges.date, dateString))
        .limit(1);

      if (existing.length === 0) {
        const theme = getThemeForDate(dateString);
        const newChallenge: InsertDailyChallenge = {
          date: dateString,
          theme: theme.theme,
          description: theme.description,
          photoIds: JSON.stringify(theme.photoIds),
          isActive: i === 0 ? 1 : 0, // Only today's is active
        };

        await db.insert(dailyChallenges).values(newChallenge);
        console.log(`[DailyChallenge] ✅ Created challenge for ${dateString}: ${theme.theme}`);
      }
    }
  } catch (error) {
    console.error('[DailyChallenge] Error initializing weekly challenges:', error);
    throw error;
  }
}

/**
 * Get statistics for a specific date's challenge
 */
export async function getDailyChallengeStats(dateString: string): Promise<{
  totalParticipants: number;
  averageScore: number;
  averageAccuracy: number;
} | null> {
  const db = await getDb();
  if (!db) {
    console.error('[DailyChallenge] Database not available');
    return null;
  }

  try {
    // Get challenge ID for the date
    const challenge = await db
      .select()
      .from(dailyChallenges)
      .where(eq(dailyChallenges.date, dateString))
      .limit(1);

    if (challenge.length === 0) {
      return null;
    }

    // This would require importing dailyChallengeScores table
    // For now, returning a placeholder
    return {
      totalParticipants: 0,
      averageScore: 0,
      averageAccuracy: 0,
    };
  } catch (error) {
    console.error('[DailyChallenge] Error getting challenge stats:', error);
    return null;
  }
}
