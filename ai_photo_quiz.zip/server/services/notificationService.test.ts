import { describe, expect, it, vi, beforeEach } from "vitest";
import { formatChallengeNotification } from "./notificationService";
import type { DailyChallenge } from "../../drizzle/schema";

describe("Notification Service", () => {
  describe("formatChallengeNotification", () => {
    it("should format challenge notification correctly", () => {
      const challenge: DailyChallenge = {
        id: 1,
        date: "2024-03-22",
        theme: "🏔️ 山景挑战",
        description: "今天的主题是壮丽的山景摄影。",
        photoIds: JSON.stringify(["photo-1", "photo-6"]),
        isActive: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = formatChallengeNotification(challenge);

      expect(result).toHaveProperty("title");
      expect(result).toHaveProperty("content");
      expect(result.title).toContain("🏔️ 山景挑战");
      expect(result.content).toContain("今天的主题是壮丽的山景摄影。");
      expect(result.content).toContain("2024-03-22");
      expect(result.content).toContain("2"); // Photo count
    });

    it("should handle challenges with different photo counts", () => {
      const challenge: DailyChallenge = {
        id: 1,
        date: "2024-03-22",
        theme: "👤 人物肖像挑战",
        description: "人物肖像主题",
        photoIds: JSON.stringify(["photo-1", "photo-2", "photo-3", "photo-4", "photo-5"]),
        isActive: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = formatChallengeNotification(challenge);

      expect(result.content).toContain("5"); // Photo count
    });

    it("should include emoji in title", () => {
      const challenge: DailyChallenge = {
        id: 1,
        date: "2024-03-22",
        theme: "🍽️ 美食摄影挑战",
        description: "美食主题",
        photoIds: JSON.stringify(["photo-1", "photo-2"]),
        isActive: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = formatChallengeNotification(challenge);

      expect(result.title).toContain("🎮");
      expect(result.title).toContain("🍽️");
    });

    it("should handle empty photo IDs gracefully", () => {
      const challenge: DailyChallenge = {
        id: 1,
        date: "2024-03-22",
        theme: "测试主题",
        description: "测试描述",
        photoIds: JSON.stringify([]),
        isActive: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = formatChallengeNotification(challenge);

      expect(result).toHaveProperty("title");
      expect(result).toHaveProperty("content");
      expect(result.content).toContain("0"); // Photo count
    });

    it("should include call-to-action in content", () => {
      const challenge: DailyChallenge = {
        id: 1,
        date: "2024-03-22",
        theme: "测试主题",
        description: "测试描述",
        photoIds: JSON.stringify(["photo-1"]),
        isActive: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = formatChallengeNotification(challenge);

      expect(result.content).toContain("快来参加挑战");
      expect(result.content).toContain("得多少分");
    });
  });
});
