CREATE TABLE `daily_challenge_scores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dailyChallengeId` int NOT NULL,
	`score` int NOT NULL,
	`totalPhotos` int NOT NULL,
	`accuracy` int NOT NULL,
	`answers` text NOT NULL,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `daily_challenge_scores_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `daily_challenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` varchar(10) NOT NULL,
	`theme` varchar(100) NOT NULL,
	`description` text,
	`photoIds` text NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_challenges_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_challenges_date_unique` UNIQUE(`date`)
);
--> statement-breakpoint
CREATE TABLE `user_daily_challenge_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dailyChallengeId` int NOT NULL,
	`participated` int NOT NULL DEFAULT 0,
	`bestScore` int,
	`bestAccuracy` int,
	`participatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_daily_challenge_progress_id` PRIMARY KEY(`id`)
);
