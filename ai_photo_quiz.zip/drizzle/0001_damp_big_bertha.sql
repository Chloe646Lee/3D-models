CREATE TABLE `leaderboard_scores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`score` int NOT NULL,
	`totalPhotos` int NOT NULL,
	`accuracy` int NOT NULL,
	`answers` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `leaderboard_scores_id` PRIMARY KEY(`id`)
);
