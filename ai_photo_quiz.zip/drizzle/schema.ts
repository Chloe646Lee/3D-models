import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Leaderboard scores table
 * Stores user quiz scores for ranking and statistics
 */
export const leaderboardScores = mysqlTable("leaderboard_scores", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  score: int("score").notNull(), // Number of correct answers
  totalPhotos: int("totalPhotos").notNull(), // Total photos in the quiz
  accuracy: int("accuracy").notNull(), // Percentage (0-100)
  answers: text("answers").notNull(), // JSON array of answers
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LeaderboardScore = typeof leaderboardScores.$inferSelect;
export type InsertLeaderboardScore = typeof leaderboardScores.$inferInsert;

/**
 * Daily Challenge table
 * Stores daily challenge configurations with theme and image sets
 */
export const dailyChallenges = mysqlTable("daily_challenges", {
  id: int("id").autoincrement().primaryKey(),
  date: varchar("date", { length: 10 }).notNull().unique(), // YYYY-MM-DD format
  theme: varchar("theme", { length: 100 }).notNull(), // e.g., "Mountain Landscapes", "Urban Architecture"
  description: text("description"), // Challenge description
  photoIds: text("photoIds").notNull(), // JSON array of photo IDs for this challenge
  isActive: int("isActive").default(1).notNull(), // 1 for active, 0 for inactive
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyChallenge = typeof dailyChallenges.$inferSelect;
export type InsertDailyChallenge = typeof dailyChallenges.$inferInsert;

/**
 * Daily Challenge Scores table
 * Stores scores for daily challenges, separate from regular leaderboard
 */
export const dailyChallengeScores = mysqlTable("daily_challenge_scores", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  dailyChallengeId: int("dailyChallengeId").notNull(),
  score: int("score").notNull(), // Number of correct answers
  totalPhotos: int("totalPhotos").notNull(), // Total photos in the challenge
  accuracy: int("accuracy").notNull(), // Percentage (0-100)
  answers: text("answers").notNull(), // JSON array of answers
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export type DailyChallengeScore = typeof dailyChallengeScores.$inferSelect;
export type InsertDailyChallengeScore = typeof dailyChallengeScores.$inferInsert;

/**
 * User Daily Challenge Progress table
 * Tracks which daily challenges users have participated in
 */
export const userDailyChallengeProgress = mysqlTable("user_daily_challenge_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  dailyChallengeId: int("dailyChallengeId").notNull(),
  participated: int("participated").default(0).notNull(), // 1 if participated, 0 otherwise
  bestScore: int("bestScore"), // Best score for this challenge
  bestAccuracy: int("bestAccuracy"), // Best accuracy for this challenge
  participatedAt: timestamp("participatedAt").defaultNow().notNull(),
});

export type UserDailyChallengeProgress = typeof userDailyChallengeProgress.$inferSelect;
export type InsertUserDailyChallengeProgress = typeof userDailyChallengeProgress.$inferInsert;
